<script>
	$(function(){
		'use strict';
		appValidateForm($('#add_edit_member'), {
			firstname: 'required',
			lastname: 'required',
			staff_identifi: 'required',
			status_work: 'required',
			job_position: 'required',
			role: 'required',
			state: 'required',
			password: {
				required: {
					depends: function(element) {
						return ($('input[name="isedit"]').length == 0) ? true : false
					}
				}
			},
			phonenumber: {
				required: true,
				remote: {
					url: site_url + "admin/misc/staff_mobile_exists",
					type: 'post',
					data: {
						phonenumber: function() {
							return $('input[name="phonenumber"]').val();
						},
						memberid: function() {
							return $('input[name="memberid"]').val();
						}
					}
				}
			},
			email: {
				required: false,
				email: true,
				remote: {
					url: site_url + "admin/misc/staff_email_exists",
					type: 'post',
					data: {
						email: function() {
							return $('input[name="email"]').val();
						},
						memberid: function() {
							return $('input[name="memberid"]').val();
						}
					}
				}
			},
			staff_identifi: {
				required: true,
				remote: {
					url: site_url + "admin/hr_profile/hr_code_exists",
					type: 'post',
					data: {
						staff_identifi: function() {
							return $('input[name="staff_identifi"]').val();
						},
						memberid: function() {
							return $('input[name="memberid"]').val();
						}
					}
				}
			}
		});

		init_datepicker();
		init_selectpicker();
		$(".selectpicker").selectpicker('refresh');

		$('select[name="role"]').on('change', function() {
			var roleid = $(this).val();
			init_roles_permissions(roleid, true);
		});


		$("input[name='profile_image']").on('change', function() {
			readURL(this);
		});
		
	
        
        $('#phonenumber').keyup(function(e) {
            e.preventDefault();
            if(!$('#phonenumber').val().match('[0-9]{10}'))  {
                
                $(".mob_denger").text("Enter valid 10 digit mobile number");
            }else{
                $(".mob_denger").text(" ");
            }
            

        });
		
		$('#state').on('change', function() {
				var id = $(this).val();
				//alert(roleid);
				var url = "<?php echo base_url(); ?>admin/hr_profile/select_city";
                    jQuery.ajax({
                        type: 'POST',
                        url:url,
                        data: {id: id},
                        dataType:'json',
                        success: function(data) {
                           
                            $(".city").html(data);
                            //alert(data);
                            
                        }
                    });
			});
			
			$('#state').on('change', function() {
				var id = $(this).val();
				//alert(roleid);
				var url = "<?php echo base_url(); ?>admin/hr_profile/select_quarter";
                    jQuery.ajax({
                        type: 'POST',
                        url:url,
                        data: {id: id},
                        dataType:'json',
                        success: function(data) {
                           
                            $(".headqurter").html(data);
                            //alert(data);
                            
                        }
                    });
			});
			
			var app_access = $("#app_access").val();
			var erp_access = $("#login_access").val();
			if(app_access == "No" && erp_access == "No"){
			    $("#password_field").css("display", "none");
			}
			
			$('#login_access').on('change', function() {
				var erp_access = $(this).val();
				var app_access = $("#app_access").val();
				if(erp_access == "Yes" || app_access == "Yes"){
				    $("#password_field").css("display", "");
				}else {
				    $("#password_field").css("display", "none");
				}
				
				
			});
			
			$('#app_access').on('change', function() {
				var app_access = $(this).val();
				var erp_access = $("#login_access").val();
				if(erp_access == "Yes" || app_access == "Yes"){
				    $("#password_field").css("display", "");
				}else {
				    $//("").css("display", "inline-table");
				    $("#password_field").css("display", "none");
				}
				
				
			});

	});

	function readURL(input) {
		"use strict";
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$("img[id='wizardPicturePreview']").attr('src', e.target.result).fadeIn('slow');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}

	function hr_profile_update_staff(staff_id) {
		"use strict";

		$("#modal_wrapper").load("<?php echo admin_url('hr_profile/hr_profile/member_modal'); ?>", {
			slug: 'update',
			staff_id: staff_id
		}, function() {
			if ($('.modal-backdrop.fade').hasClass('in')) {
				$('.modal-backdrop.fade').remove();
			}
			if ($('#appointmentModal').is(':hidden')) {
				$('#appointmentModal').modal({
					show: true
				});
			}
		});

		init_selectpicker();
		$(".selectpicker").selectpicker('refresh');
	}

</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
              <div class="_buttons">
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="act_name">A/c no</label>
                            <input type="text" name="act_name" id="act_name" class="form-control" value="<?php echo $value; ?>" <?php if(isset($cd_notes_details)){ echo "disabled";} ?>>
                                        
                        </div>
                    </div>
                    <div class="col-md-4">
                        <br>
                        <div class="form-group">
                        <input type="text" name="account_full_name" id="account_full_name" class="form-control" value="<?php echo $value; ?>">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="act_name">Item ID</label>
                            <input type="text" name="item_code" id="item_code" style="width: 100%;border-radius: 2px;height: 30px;">
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <br>
                            <div class="form-group">
                            <input type="text" name="item_fill_name" id="item_fill_name" class="form-control" value="<?php echo $value; ?>">
                            </div>
                        </div>
                    </div>
                 
                
                <div class="row"> 
                    <?php
                        $fy = $this->session->userdata('finacial_year');
                        $fy_new  = $fy + 1;
                        $lastdate_date = '20'.$fy_new.'-03-31';
                        $firstdate_date = '20'.$fy_new.'-04-01';
                        $curr_date = date('Y-m-d');
                        $curr_date_new    = new DateTime($curr_date);
                        $last_date_yr = new DateTime($lastdate_date);
                        if($last_date_yr < $curr_date_new){
                            $to_date = '31/03/20'.$fy_new;
                            $from_date = '01/03/20'.$fy_new;
                        }else{
                            $from_date = "01/".date('m')."/".date('Y');
                            $to_date = date('d/m/Y');
                        }
                    ?>
                       <div class="col-md-2">
                           
                            <?php echo render_date_input('from_date','FROM',$from_date);  ?>
                        </div>
                        
                        <div class="col-md-2">
                            
                            <?php echo render_date_input('to_date','TO',$to_date); ?>
                        </div>
                        
                        <div class="col-md-2">
                            <br>
                            <div class="form-group">
                           <select name="report_type" id="report_type" class="form-control">
                               <option value="1">Detailed</option>
                               <option value="2">Summary</option>
                               <option value="3">ItemDetails</option>
                           </select>
                           </div>
                        </div>
                    <div class="col-md-1">
                    <br>
                    <div class="custom_button">
                        <button class="btn btn-info pull-left mleft5 search_data" id="search_data" style="font-size:12px;">Show</button>
                    </div>
                </div>
                <div class="col-md-2">
                    <br>
                            <div class="custom_button">
                               <a class="btn btn-default buttons-excel buttons-html5" tabindex="0" aria-controls="table-daily_report" href="#" id="caexcel"><span>Export to excel</span></a>
                                <!--<a class="dt-button buttons-pdf buttons-html5" tabindex="0" aria-controls="ca_datatable" href="#"><span>Export to PDF</span></a>-->
                            </div>
                </div>    
                
        
             </div>
        
               
            </div>
            <div class="clearfix"></div>
            
        <?php
        //print_r($company_detail);
        ?>
        <span id="searchh3" style="display:none;">Please wait exporting data...</span>
            <div class="fixTableHead load_data">
              
            </div>
            <span id="searchh" style="display:none;">Loading.....</span>
    
            
          </div>
</div>
</div>
</div>
</div>
</div>
<style>

.fixTableHead  { overflow: auto;max-height: 50vh;width:100%;position:relative;top: 0px; }
.fixTableHead thead th { position: sticky; top: 0; z-index: 1; }
.fixTableHead tbody th { position: sticky; left: 0; }

/* Just common table stuff. Really. */
.fixTableHead table  { border-collapse: collapse; width: 100%; }
th, td { padding: 1px 5px !important; white-space: nowrap; border:1px solid !important;font-size:11px; line-height:1.42857143!important;vertical-align: middle !important;}
.fixTableHead th     { background: #50607b;color: #fff !important; }
</style>

<?php init_tail(); ?>
<!--new update -->
<script src="<?= base_url() ?>public/plugins/jquery.table2excel.js"></script>
<script type="text/javascript" language="javascript" >
$(document).ready(function(){
    

// Initialize For Account
     $( "#act_name" ).autocomplete({
        
        source: function( request, response ) {
          // Fetch data
          
          $.ajax({
            url: "<?=base_url()?>admin/purchase/accountlist",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data );
            }
          });
        },
        select: function (event, ui) {
          
          
          $('#act_name').val(ui.item.value); // display the selected text
          $('#account_full_name').val(ui.item.label); // display the selected text
          
            return false;      
            
        }
      });
    
    $('#act_name').on('blur',function(){
         
        var act_id = $(this).val();
        $.ajax({
          url:"<?php echo admin_url(); ?>purchase/get_account_details",
          dataType:"JSON",
          method:"POST",
          cache: false,
          data:{act_id:act_id,},
          
          success:function(data){
            var ItemID = $('#item_code').val();
            if (data == 0 || data == null){
                if(act_id !== ""){
                   alert("AccountID not found..."); 
                }
                $('#act_name').val('');
                $('#account_full_name').val('');
                if(ItemID == ""){
                    $("#report_type").children().remove();
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                    $('#report_type').append('<option value="1">Detailed</option>');
                    $('#report_type').append('<option value="2">Summary</option>');
                    $('#report_type').append('<option value="3">ItemDetails</option>');
                    $("#report_type").selectpicker("refresh");
                }
                
            }else{
                $('#account_full_name').val(data.company);
                
                $("#report_type").children().remove();
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                $('#report_type').append('<option value="3">ItemDetails</option>');
                             
                $("#report_type").selectpicker("refresh");
                $('#search_data').focus();
                
            }
              
            $('#account_full_name').val(data.company);
           $('#search_data').focus();
            
          }
        });
        
     })
     
    $('#item_code').on('blur',function(){
         
        var ItemID = $(this).val();
        $.ajax({
          url:"<?php echo admin_url(); ?>purchase/get_item_details",
          dataType:"JSON",
          method:"POST",
          cache: false,
          data:{ItemID:ItemID,},
          
          success:function(data){
            var AccounID = $('#act_name').val();
            if (data == 0 || data == null){
                if(ItemID !== ""){
                    alert("ItemID not found...");
                }
                
                $('#item_code').val('');
                $('#item_fill_name').val('');
                if(AccounID == ""){
                    $("#report_type").children().remove();
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                    $('#report_type').append('<option value="1">Detailed</option>');
                    $('#report_type').append('<option value="2">Summary</option>');
                    $('#report_type').append('<option value="3">ItemDetails</option>');
                    $("#report_type").selectpicker("refresh");
                }
                
            }else{
                $('#item_fill_name').val(data.description);
                
                $("#report_type").children().remove();
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                $('#report_type').append('<option value="3">ItemDetails</option>');
                             
                $("#report_type").selectpicker("refresh");
                $('#search_data').focus();
                
            }
            
            
          }
        });
        
     })
     
    $('#report_type').on('change',function(){
         
        var report_type = $(this).val();
        
        if(report_type == 3){
            var ItemID = $('#item_code').val();
            var AccounID = $('#act_name').val();
            if(ItemID == ""){
                alert("Enter ItemID"); 
                    $("#report_type").children().remove();
                    // APPEND OR INSERT DATA TO SELECT ELEMENT.
                    $('#report_type').append('<option value="1">Detailed</option>');
                    $('#report_type').append('<option value="2">Summary</option>');
                    $('#report_type').append('<option value="3">ItemDetails</option>');
                    $("#report_type").selectpicker("refresh");
                    //$('#item_code').focus();
            }
        }
    });
      // Initialize For Account
     $( "#item_code" ).autocomplete({
         
        source: function( request, response ) {
          // Fetch data
          
          $.ajax({
            url: "<?=base_url()?>admin/purchase/itemlist",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data );
            }
          });
        },
        select: function (event, ui) {
          
          
          $('#item_code').val(ui.item.value); // display the selected text
          $('#item_fill_name').val(ui.item.label); // display the selected text
          $('#search_data').focus();
            return false;      
            
        }
      });
 
 $('#search_data').on('click',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var report_type = $("#report_type").val();
	    var accountID = $("#act_name").val();
	    var accountName = $("#account_full_name").val();
	    var ItemID = $("#item_code").val();
	    var Itemname = $("#item_fill_name").val();
	    
	        $.ajax({
          url:"<?php echo admin_url(); ?>purchase/get_purchase_data",
          dataType:"JSON",
          method:"POST",
          cache: false,
          data:{from_date:from_date, to_date:to_date, report_type:report_type,accountID:accountID,ItemID:ItemID,accountName:accountName,Itemname:Itemname},
          beforeSend: function () {
                   
            $('#searchh').css('display','block');
            $('.load_data').css('display','none');
            
         },
          complete: function () {
            $('.load_data').css('display','');
            $('#searchh').css('display','none');
         },
          success:function(data){
                $('.load_data').html(data);
          }
        });
	    
 });
});

 $("#caexcel").click(function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var report_type = $("#report_type").val();
	    var accountID = $("#act_name").val();
	    var accountName = $("#account_full_name").val();
	    var ItemID = $("#item_code").val();
	    var Itemname = $("#item_fill_name").val();
	    
	    $.ajax({
            url:"<?php echo admin_url(); ?>purchase/export_purchase_register",
            method:"POST",
            data:{from_date:from_date, to_date:to_date, report_type:report_type,accountID:accountID,ItemID:ItemID,accountName:accountName,Itemname:Itemname},
            beforeSend: function () {
                $('#searchh3').css('display','block');
                
            },
            complete: function () {
                
                $('#searchh3').css('display','none');
            },
            success:function(data){
                response = JSON.parse(data);
                window.location.href = response.site_url+response.filename;
            }
        });
});

    $(document).ready(function() {
  $('tbody').scroll(function(e) { //detect a scroll event on the tbody
  	/*
    Setting the thead left value to the negative valule of tbody.scrollLeft will make it track the movement
    of the tbody element. Setting an elements left value to that of the tbody.scrollLeft left makes it maintain 			it's relative position at the left of the table.    
    */
    $('thead').css("left", -$("tbody").scrollLeft()); //fix the thead relative to the body scrolling
    $('thead th:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first cell of the header
    $('tbody td:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first column of tdbody
  });
});
</script>
<style>
    input[type=checkbox], input[type=radio] {
    margin: 4px 4px 0px;
    line-height: normal;
}
</style>

<script>
    $(document).ready(function(){
    var maxEndDate = new Date('Y/m/d');
    var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
    
    var year = "20"+fin_y;
    var cur_y = new Date().getFullYear().toString().substr(-2);
    if(cur_y => fin_y){
        var year2 = parseInt(fin_y) + parseInt(1);
        var year2_new = "20"+year2;
        
        var e_dat = new Date(year2_new+'/03/31');
        
        var maxEndDate_new = e_dat;
    }else{
        var e_dat2 = new Date(year2+'/03/31');
        var maxEndDate_new = e_dat2;
    }
    
    var minStartDate = new Date(year, 03);
   
    
    $('#from_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    
    $('#to_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false,
        showOtherMonths: false,
        pickTime: false,
            orientation: "left",
    });
    
    });
</script>



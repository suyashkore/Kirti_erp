<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="row">
			<?php
			echo form_open($this->uri->uri_string(),array('id'=>'pur_order-form','class'=>'_transaction_form'));
			
			?>
			<div class="col-md-12">
        <div class="panel_s accounting-template estimate">
        <div class="panel-body">
      
           <?php
                  $customer_custom_fields = false;
                  if(total_rows(db_prefix().'customfields',array('fieldto'=>'pur_order','active'=>1)) > 0 ){
                       $customer_custom_fields = true;
                  }
                   ?>
            <div class="tab-content">
                <?php if($customer_custom_fields) { ?>
                 <div role="tabpanel" class="tab-pane" id="custom_fields">
                    <?php $rel_id=( isset($pur_order) ? $pur_order->id : false); ?>
                    <?php echo render_custom_fields( 'pur_order',$rel_id); ?>
                 </div>
                <?php } ?>
                <div role="tabpanel" class="tab-pane active" id="general_infor">
                <div class="row">
                  <!-- <div class="col-md-3">
                    
                             <div class="form-group ">
                          <?php $prefix = get_purchase_option('pur_order_prefix');
                                $next_number = get_purchase_option('next_po_number');
                          //$pur_order_number = (isset($pur_order) ? $pur_order->pur_order_number : $prefix.'-'.str_pad($next_number,5,'0',STR_PAD_LEFT).'-'.date('M-Y'));
                          $pur_order_number = (isset($pur_order) ? $pur_order->pur_order_number : $prefix.'-'.str_pad($next_number,5,'0',STR_PAD_LEFT));
                          
                          $number = (isset($pur_order) ? $pur_order->number : $next_number);
                          echo form_hidden('number',$number); ?> 
                          
                          <label for="pur_order_number"><?php echo _l('pur_order_number'); ?></label>
                          
                              <input type="text"  class="form-control" name="pur_order_number" value="<?php echo html_entity_decode($pur_order_number); ?>">
                          
                        </div>
                        </div>-->
                    <div class="col-md-3">
				                   <?php
                        $selected_company = $this->session->userdata('root_company');
                        $fy = $this->session->userdata('finacial_year');
                        if($selected_company == 1){
                        
                        $new_purchase_orderNumbar = get_option('next_purchase_number_for_cspl');
                    }elseif($selected_company == 2){
                        $new_purchase_orderNumbar = get_option('next_purchase_number_for_cff');
                    }elseif($selected_company == 3){
                        $new_purchase_orderNumbar = get_option('next_purchase_number_for_cbu');
                    }
                    
                    $format = get_option('invoice_number_format');
               
						$prefix = get_purchase_option('pur_order_prefix');
					   if ($format == 1) {
						 $__number = $new_purchase_orderNumbar;
						 $prefix = $prefix.'<span id="prefix_year">'.$fy.'</span>';
					   } else if($format == 2) {
						 
						  $__number = $new_purchase_orderNumbar;
						  $prefix = $prefix.'<span id="prefix_year">'.$fy.'</span>/';
						
					   } else if($format == 3) {
						  
						  $__number = $new_purchase_orderNumbar;
						
					   } else if($format == 4) {
						  
						  $yyyy = date('Y');
						  $mm = date('m');
						  $__number = $new_purchase_orderNumbar;						
					   }
				    
                   $_production_number = str_pad($__number, get_option('number_padding_prefixes'), '0', STR_PAD_LEFT);
                 ?> 
					 <div class="form-group">
                           <label for="number"> 
                             Production Order Number
                            					 
                             <!-- <i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo _l('invoice_number_not_applied_on_draft') ?>" data-placement="top"></i>-->
                        </label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <?php
                          echo $prefix;
                        ?>
                    </span>
                      <input type="text" name="pro_orderid" id="pro_orderid" class="form-control receiptsid" value="<?php echo ($_is_draft) ? 'DRAFT' : $_production_number; ?>" data-isedit="<?php echo $isedit; ?>" data-original-number="<?php echo $data_original_number; ?>" <?php echo ($_is_draft) ? 'disabled' : '' ?>>
                    </div>
                    </div>
						
                </div>   
                          
                          <div class="col-md-3">
                           <?php $order_date = (isset($pur_order) ? _d($pur_order->order_date) : _d(date('Y-m-d')));
                        echo render_date_input('prd_date','Receipt Date',$order_date); ?>
                             
                       
                       
                      </div>
                      <div class="col-md-3">
                          <br>
                          <span></span><a href="#" class="btn btn-primary edit-new-order">View List</a>
                          </div>
                      <div class="col-md-1"></div>
                      <div class="col-md-2"></div>
                            
                            
                            
                            
                            
                         
                
                       


                      
                      <!--<div class="row">-->
                       
                        <?php// if(get_purchase_option('purchase_order_setting') == 0 ){ ?>
                      <!--    <div class="col-md-5 form-group">-->
                      <!--      <label for="estimate"><?php echo _l('estimates'); ?></label>-->
                      <!--      <select name="estimate" id="estimate" class="selectpicker"  data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >-->
                              
                      <!--      </select>-->
                      <!--      <br><br>-->
                      <!--    </div>-->
                      <!--    <div class="col-md-1 pad_div_0">-->
                      <!--      <a href="#" onclick="coppy_pur_estimate(); return false;" class="btn btn-success mtop25" data-toggle="tooltip" title="<?php echo _l('coppy_pur_estimate'); ?>">-->
                      <!--      <i class="fa fa-clone"></i>-->
                      <!--      </a>-->
                      <!--    </div>-->
                      <?php //} ?>

                      <!--</div>-->

                      
                       
                     
                      </div>
                       <div class="row">
                       <!--<div class="col-md-3">
                              <div class="form-group">
                        <label for="vendor"><?php echo _l('vendor'); ?></label>
                        <select name="vendor" id="vendor" class="selectpicker" onchange="estimate_by_vendor(this); return false;" data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >
                        <option value=""></option>
                        <?php foreach($vendors as $s) { ?>
                        <option value="<?php echo html_entity_decode($s['userid']); ?>" <?php if(isset($pur_order) && $pur_order->vendor == $s['userid']){ echo 'selected'; }else{ if(isset($ven) && $ven == $s['userid']){ echo 'selected';} } ?>><?php echo html_entity_decode($s['company']); ?></option>
                        <?php } ?>
                        </select>              
                        </div>
                          
                              </div>-->
                        
                        <div class="col-md-3">
                            <label for="vendor"><?php echo _l('vendor'); ?></label>
                                <select name="vendor" id="vendor" class="selectpicker" data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >
                                  <option value=""></option>
                                    <?php foreach($vendors as $s) { ?>
                                    <option value="<?php echo html_entity_decode($s['userid']); ?>" ><?php echo html_entity_decode($s['company'])." - ".html_entity_decode($s['AccountID']); ?></option>
                                      <?php } ?>
                                </select>  
                                <br><br>
                          </div>

                   <div class="col-md-3 ">
                         <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="c_name" id="c_name"  aria-invalid="false">
                           
                          </div>
                         
                      </div>
                        <div class="col-md-3 ">
                         <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="gst_num" id="gst_num"  aria-invalid="false">
                           
                          </div>
                         
                      </div>
                       <div class="col-md-3 ">
                         <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="c_balance" id="c_balance"  aria-invalid="false">
                           
                          </div>
                         
                      </div>

                      <!--<div class="col-md-6">-->
                                   <?php
                                //   $selected = '';
                                //   foreach($staff as $member){
                                //   if(isset($pur_order)){
                                //      if($pur_order->buyer == $member['staffid']) {
                                //       $selected = $member['staffid'];
                                //      }
                                //   }else{
                                //     if($member['staffid'] == get_staff_user_id()){
                                //       $selected = $member['staffid'];
                                //     }
                                //   }
                                //   }
                                //   echo render_select('buyer',$staff,array('staffid',array('firstname','lastname')),'buyer',$selected);
                                  ?>
                      <!--</div>-->
                    </div>
                     <div class="row">
                      <div class="col-md-3">
                              <div class="form-group">
                            <label for="invoce_n">Invoice Number</label>
                           <input type="text"  class="form-control" name="invoce_n" id="invoce_n"  aria-invalid="false">
                           
                          </div>
                          
                </div>
                       <div class="col-md-3 ">
                         <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="address" id="address"  aria-invalid="false">
                           
                          </div>
                         
                      </div>
                     
                         <div class="col-md-3">
                              <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="station_n" id="station_n"  aria-invalid="false">
                           
                          </div>
                          
                </div>
                <div class="col-md-3">
                              <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="address2" id="address2"  aria-invalid="false">
                           
                          </div>
                          
                </div>
                      <?php //$clients_ed = (isset($pur_order) ? explode(',',$pur_order->clients) : []); ?>
                      <!--<div class="col-md-6">-->
                      <!--  <label for="clients"><?php echo _l('clients'); ?></label>-->
                      <!--  <select name="clients[]" id="clients" class="selectpicker" data-live-search="true" multiple data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >-->

                            <?php //foreach($clients as $s) { ?>
                            <!--<option value="<?php echo html_entity_decode($s['userid']); ?>" <?php if(isset($pur_order) && in_array($s['userid'], $clients_ed)){ echo 'selected'; } ?>><?php echo html_entity_decode($s['company']); ?></option>-->
                              <?php// } ?>
                      <!--  </select>-->
                      <!--</div>-->

                      <!--<div class="col-md-5 form-group">-->
                      <!--  <label for="pur_request"><?php echo _l('pur_request'); ?></label>-->
                      <!--  <select name="pur_request" id="pur_request" class="selectpicker"  data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >-->
                      <!--    <option value=""></option>-->
                      <!--      <?php foreach($pur_request as $s) { ?>-->
                      <!--      <option value="<?php echo html_entity_decode($s['id']); ?>" <?php if(isset($pur_order) && $pur_order->pur_request != '' && $pur_order->pur_request == $s['id']){ echo 'selected'; } ?> ><?php echo html_entity_decode($s['pur_rq_code'].' - '.$s['pur_rq_name']); ?></option>-->
                      <!--        <?php } ?>-->
                      <!--  </select>-->
                      <!-- </div>-->
                      <!--<div class="col-md-1 pad_div_0">-->
                      <!--  <a href="#" onclick="coppy_pur_request(); return false;" class="btn btn-success mtop25" data-toggle="tooltip" title="<?php echo _l('coppy_pur_request_to_purorder'); ?>">-->
                      <!--  <i class="fa fa-clone"></i>-->
                      <!--  </a>-->
                      <!--</div> -->

                      <!--<div class="col-md-12 form-group">-->
                      <!--<label for="department"><?php echo _l('department'); ?></label>-->
                      <!--  <select name="department" id="department" class="selectpicker" data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>">-->
                      <!--    <option value=""></option>-->
                      <!--    <?php foreach($departments as $s) { ?>-->
                      <!--      <option value="<?php echo html_entity_decode($s['departmentid']); ?>" <?php if(isset($pur_order) && $s['departmentid'] == $pur_order->department){ echo 'selected'; } ?>><?php echo html_entity_decode($s['name']); ?></option>-->
                      <!--      <?php } ?>-->
                      <!--  </select>-->
                      <!--  <br><br>-->
                      <!--</div>-->
                   </div> 
                   <div class="row">
                      
               
              </div>
              <div class="row">
                       <div class="col-md-3">
                             <?php $order_date = (isset($pur_order) ? _d($pur_order->order_date) : _d(date('Y-m-d')));
                        echo render_date_input('invoce_date','Invoice date',$order_date); ?>
                          
                </div>
                 <div class="col-md-3">
                 <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="city" id="city"  aria-invalid="false">
                           
                          </div>
                          </div>
                <div class="col-md-1">
                <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="state_c" id="state_c"  aria-invalid="false">
                           
                          </div>
                          </div>
                           <div class="col-md-2">
                <div class="form-group">
                            <label for="estimate"></label>
                           <input type="text" readonly="" class="form-control" name="state_f" id="state_f"  aria-invalid="false">
                           
                          </div>
                          </div>
                          
             </div>
                   
                

              </div>
            </div>
        </div>
        <div class="panel-body mtop10">
        <div class="row col-md-12">
        <p class="bold p_style"><?php echo _l('pur_order_detail'); ?></p>
        <hr class="hr_style"/>
         <div class="" id="example">
         </div>
         <?php echo form_hidden('pur_order_detail'); ?>
         <div class="col-md-4">
             </div>
         <div class="col-md-4">
              <table class="table text-right">
               <tbody>
             <tr id="discount_area">
             <td class="td_style" style="float: right;">
                           <label style="float: left; padding: 9px;" for="<?php echo _l('Freight A/c'); ?>"><?php echo _l('Freight A/c'); ?></label>  
                     
                                
                              <input  type="text" readonly class=" text-right" name="Freight_1" size="7" value="<?php echo $freight_id->AccountID?>">
                               <!--<input  type="text" disabled="true" class=" text-right" name="Freight_2" size="11" value="">-->
                        <select size="11" name="Freight_2" id="Freight_2" class="selectpicker"  data-live-search="true" data-width="40%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >
                        <option value=""></option>
                        <?php foreach($accounts as $s) { ?>
                        <option value="<?php echo html_entity_decode($s['userid']); ?>" <?php if('FREIGHT INWARD' == $s['company']){ echo 'selected';} ?>><?php echo html_entity_decode($s['company']); ?></option>
                        <?php } ?>
                        </select>
                       
                         
                          
                     </td>
                     </tr>
                     <tr  id="discount_area">
                      <td class="td_style" style="float: right;">
                           <label style="float: left; padding: 9px;" for="<?php echo _l('Other A/c'); ?>"><?php echo _l('Other A/c'); ?></label>  
                     
                                
                              <input  type="text" readonly class=" text-right" name="Other_ac" size="7" value="<?php echo $other_id->AccountID?>">
                               <!--<input  type="text" disabled="true" class=" text-right" name="Other_ac1" size="11" value="">-->
                              <select size="11" name="Other_ac1" id="Other_ac1" class="selectpicker"  data-live-search="true" data-width="40%" data-none-selected-text="<?php echo _l('ticket_settings_none_assigned'); ?>" >
                        <option value=""></option>
                        <?php foreach($accounts as $s) { ?>
                        <option value="<?php echo html_entity_decode($s['userid']); ?>" <?php if('MISC. EXPENCES' == $s['company']){ echo 'selected';} ?>><?php echo html_entity_decode($s['company']); ?></option>
                        <?php } ?>
                        </select>
                       
                         
                          
                     </td>
                  </tr>
                  </tbody>
                  </table>
         </div>
         <div class="col-md-4 ">
            <table class="table text-right">
               <tbody>
                  <tr id="total_td">
                     
                     <td width="50%" id="total_td">
                      <label style="float: left; padding: 9px;" for="<?php echo _l('subtotal'); ?>"><?php echo _l('subtotal'); ?></label>  
                       <div class="input-group" id="discount-total">
                                
                              <input type="text" readonly class="form-control text-right" name="total_mn" value="">

                             

                          </div>
                     </td>
                     <td width="50%" class="td_style">
                           <label style="float: left; padding: 9px; 0px;" for="<?php echo _l('TCS%'); ?>"><?php echo _l('TCS%'); ?></label>  
                     
                                
                              <input  type="text" readonly class=" text-right" name="tcs_pre" size="2" value="" >
                               <input  type="text" readonly class=" text-right" name="tcs_pre_data" size="4" value="" >

                       
                         
                          
                     </td>
                  </tr>
                  <!--<tr id="discount_area">-->
                  <!--    <td>-->
                  <!--        <span class="bold"><?php echo _l('estimate_discount'); ?></span>-->
                  <!--    </td>-->
                  <!--    <td>  -->
                  <!--        <div class="input-group" id="discount-total">-->
                  <!--           <input type="number" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_percent,''); } ?>" onchange="dc_percent_change(this); return false;" class="form-control pull-left input-percent text-right" min="0" max="100" name="dc_percent">-->
                  <!--           <div class="input-group-addon">-->
                  <!--              <div class="dropdown">-->
                                   
                  <!--                 <span class="discount-type-selected">%</span>-->
                                  
                  <!--              </div>-->
                  <!--           </div>-->
                  <!--        </div>-->
                  <!--   </td>-->
                  <!--</tr>-->
                  
                  <tr id="discount_area">
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">Discount AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" readonly value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" onchange="dc_total_change(this); return false;" data-type="currency" name="dc_total">

                             

                          </div>
                     </td>
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">Freight AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" value="0" class="form-control pull-left text-right"  data-type="currency" name="Freight_AMT" id="Freight_AMT">


                          </div>
                     </td>
                  </tr>
                  <tr id="discount_area">
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">CGST AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" readonly value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" data-type="currency" name="CGST_amt">

                            

                          </div>
                     </td>
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">Other AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" value="0" class="form-control pull-left text-right"  data-type="currency" id="Other_amt" name="Other_amt">

                             

                          </div>
                     </td>
                  </tr>
                  <tr id="discount_area">
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">SGST AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" readonly value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" onchange="dc_total_change(this); return false;" data-type="currency" name="SGST_AMT">

                             

                          </div>
                     </td>
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">Round OFF</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" readonly value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" onchange="dc_total_change(this); return false;" data-type="currency" name="Round_OFF">

                            

                          </div>
                     </td>
                  </tr>
                  <tr id="discount_area">
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">IGST AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" readonly  value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" onchange="dc_total_change(this); return false;" data-type="currency" name="IGST_amt">

                          

                          </div>
                     </td>
                         <td>  
                     <label style="float: left; padding: 9px 9px 9px 0px;" for="<?php echo _l('subtotal'); ?>">Invoice AMT</label>  
                          <div class="input-group" id="discount-total">
                             <input type="text" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->discount_total,''); } ?>" class="form-control pull-left text-right" onchange="dc_total_change(this); return false;" data-type="currency" name="Invoice_amt">

                           

                          </div>
                     </td>
                  </tr>
                  <!--<tr>-->
                  <!--   <td class="td_style"><span class="bold"><?php echo _l('after_discount'); ?></span>-->
                  <!--   </td>-->
                  <!--   <td width="55%" id="total_td">-->
                      
                  <!--     <div class="input-group" id="discount-total">-->

                  <!--           <input type="text" disabled="true" class="form-control text-right" name="after_discount" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->total - $pur_order->discount_total,''); } ?>">-->

                  <!--           <div class="input-group-addon">-->
                  <!--              <div class="dropdown">-->
                                   
                  <!--                 <span class="discount-type-selected">-->
                  <!--                  <?php echo html_entity_decode($base_currency->name) ;?>-->
                  <!--                 </span>-->
                  <!--              </div>-->
                  <!--           </div>-->

                  <!--        </div>-->
                  <!--   </td>-->

                  <!--</tr>-->

                  <!--<tr id="discount_area">-->
                  <!--    <td>-->
                  <!--        <span class="bold"><?php echo _l('tax'); ?></span>-->
                  <!--    </td>-->
                  <!--    <td>  -->
                  <!--        <div class="input-group" id="discount-total">-->
                  <!--           <input type="number" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->tax_order_rate,''); } ?>" onchange="tax_percent_change(this); return false;" class="form-control pull-left input-percent text-right" min="0" max="100" name="tax_order_rate">-->
                  <!--           <div class="input-group-addon">-->
                  <!--              <div class="dropdown">-->
                                   
                  <!--                 <span class="discount-type-selected">%</span>-->
                                  
                  <!--              </div>-->
                  <!--           </div>-->
                  <!--        </div>-->
                  <!--   </td>-->
                  <!--</tr>-->
                  <!--<tr id="discount_area">-->
                  <!--    <td>-->
                  <!--        <span class="bold"><?php echo _l('tax_amount'); ?></span>-->
                  <!--    </td>-->
                  <!--    <td>  -->
                  <!--        <div class="input-group" id="discount-total">-->

                  <!--           <input type="text" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->tax_order_amount,''); } ?>" class="form-control pull-left text-right" onchange="tax_amount_change(this); return false;" data-type="currency" name="tax_order_amount" readonly>-->

                  <!--           <div class="input-group-addon">-->
                  <!--              <div class="dropdown">-->
                                   
                  <!--                 <span class="discount-type-selected">-->
                  <!--                  <?php echo html_entity_decode($base_currency->name) ;?>-->
                  <!--                 </span>-->
                                   
                                   
                  <!--              </div>-->
                  <!--           </div>-->

                  <!--        </div>-->
                  <!--   </td>-->
                  <!--</tr>-->
                  <!--<tr>-->
                  <!--   <td class="td_style"><span class="bold"><?php echo _l('grand_total'); ?></span>-->
                  <!--   </td>-->
                  <!--   <td width="55%" id="total_td">-->
                  <!--     <div class="input-group" id="discount-total">-->

                  <!--           <input type="text" disabled="true" class="form-control text-right" name="grand_total" value="<?php if(isset($pur_order)){ echo app_format_money($pur_order->total,''); } ?>">-->

                  <!--           <div class="input-group-addon">-->
                  <!--              <div class="dropdown">-->
                                   
                  <!--                 <span class="discount-type-selected">-->
                  <!--                  <?php echo html_entity_decode($base_currency->name) ;?>-->
                  <!--                 </span>-->
                  <!--              </div>-->
                  <!--           </div>-->

                  <!--        </div>-->
                  <!--   </td>-->
                  <!--</tr>-->

               </tbody>
            </table>
         </div> 
         
        </div>
        </div>
        <div class="row">
          <div class="col-md-12 mtop15">
             <div class="panel-body bottom-transaction">
                <?php// $value = (isset($pur_order) ? $pur_order->vendornote : get_purchase_option('vendor_note')); ?>
                <?php// echo render_textarea('vendornote','estimate_add_edit_vendor_note',$value,array(),array(),'mtop15'); ?>
                <?php// $value = (isset($pur_order) ? $pur_order->terms :  get_purchase_option('terms_and_conditions')); ?>
                <?php //echo render_textarea('terms','terms_and_conditions',$value,array(),array(),'mtop15'); ?>
                <div id="vendor_data">
                  
                </div>

                <div class="btn-bottom-toolbar text-right" style="width: 100%;">
                  
                  <button type="button"  class="btn-tr save_detail btn btn-info mleft10 estimate-form-submit transaction-submit">
                  <?php echo _l('submit'); ?>
                  </button>
                </div>
             </div>
               <div class="btn-bottom-pusher"></div>
          </div>
        </div>
        </div>

			</div>
			<?php echo form_close(); ?>
			
		</div>
	</div>
</div>
</div>
<style>
/*    @media (min-width: 768px)*/ 
/*        .modal-xl {*/
/*    width: 90%;*/
/*    max-width: 1230px;*/
/*}*/
</style>
<div class="modal fade" id="transfer-modal">
   <div class="modal-dialog modal-xl" style=" max-width: 1230px;">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">order List</h4>
         </div>
         
         
         <div class="modal-body" style="padding:5px;">
             
            <div class="row">
                <div class="col-md-12">
                    <?php 
                    //print_r($sale_returns);
                    ?>
                    <table class="table table-striped table-bordered" id="table_id" style="font-size:12px;" width="100%">
                       <thead>
                          <tr>
                             <th style="width:1% ">BT</th>
                             <th style="width:7% ">PurchID</th>
                             <th style="width:5% ">Date</th>
                             <th style="width:15% text-align:left;">PurchasedForm</th>
                             <th style="width:5% text-align:left;">InvoceNo</th>
                             <th style="width:5% text-align:left;">Date</th>
                             <th style="width:5% text-align:left;">Purchamt</th>
                             <th style="width:3% text-align:left;">Dsc</th>
                             <th style="width:5% text-align:left;">CGSTAmt</th>
                             <th style="width:5% text-align:left;">SGSTAmt</th>
                             <th style="width:5% text-align:left;">IGSTAmt</th>
                             <th style="width:5% text-align:left;">TCSAmt</th>
                             <th style="width:5% text-align:left;">FrtAmt</th>
                             <th style="width:5% text-align:left;">OthAmt</th>
                             <th style="width:5% text-align:left;">Invamt</th>
                             <th style="width:8% text-align:left;">Action</th>
                          </tr>
                       </thead>
                       <tbody>
                           <?php
                           foreach ($Order_list as $key => $value) {
                           ?>
                           <tr>
                                 <td style="width:1%;text-align:center;"><?php  echo $value["BT"];?></td>
                           <td style="width:7%;text-align:center;"><?php echo $value["PurchID"];?></td>
                         
                           <td style="width:5%;text-align:center;"><?php echo  _d(substr($value["Transdate"],0,10));?></td>
                           <td style="width:15%;text-align:left;"><?php echo $value["company"];?></td>
                           <td style="width:5%;text-align:center;"><?php echo $value["Invoiceno"];?></td>
                           <td style="width:5%;text-align:center;"><?php echo  _d(substr($value["Invoicedate"],0,10));?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["Purchamt"];?></td>
                           <td style="width:3%;text-align:right;"><?php echo $value["Discamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["cgstamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["sgstamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["igstamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["tcsAmt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["Frtamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["Othamt"];?></td>
                           <td style="width:5%;text-align:right;"><?php echo $value["Invamt"];?></td>
                           <td style="width:8%;text-align:center;"><a href="<?php echo admin_url('purchase/order_list/' . $value['PurchID']) ?>" class="text-success">Select</a></td>
                           </tr>
                           <?php
                           }
                           ?>
                       </tbody>
                    </table>
                </div>
              </div>
              
         </div>
        <!-- <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _l('close'); ?></button>
            <button type="submit" class="btn btn-info btn-submit"><?php echo _l('submit'); ?></button>
         </div>-->
         
      </div>
   </div>
</div>
<?php init_tail(); ?>
</body>
<style>
    table.dataTable tbody td {
    padding: 4px 4px !important;
    font-size: 11px;
}
</style>
</html>
<?php require 'modules/purchase/assets/js/pur_order_js.php';?>
<script>
    $(document)
  .ready(function () {
    $('#table_id')
      .DataTable({
        "order": [[ 1, "desc" ],[ 2, "false" ]]
    });
  });
</script>
<!-- Script -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
    
    <!-- jQuery UI -->
   <!-- <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>-->
    
 <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>

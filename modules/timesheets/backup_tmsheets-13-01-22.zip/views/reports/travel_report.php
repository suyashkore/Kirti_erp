<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="travel_report" class="hide reports_fr2" >
    <div class="first_table1" id="first_table1">
   <table class="table table-travel_report scroll-responsive">
    <thead>
      <tr> 
         
         <th>Staff Name</th>
         <th>Date</th>
         <th>In</th>
         <th>Out</th>
         <th>State</th>
         <th >City</th>
         <th>Position</th>
         <th>Km Trav.</th>
         <th>Report To</th>
      </tr>
   </thead>
   <tbody></tbody>
   <tfoot>
     
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      
   </tfoot>
</table>
</div>

<div class="second_table1" id="second_table1">
   <table class="table table-travel_report2 scroll-responsive">
    <thead>
      <tr> 
         
         <!--<th>Staff Name</th>-->
         <th style="width:9%;">Date</th>
         <th style="width:5%;">In</th>
         <th style="width:22.5%;">In Loc.</th>
         <th style="width:5%;">Out</th>
         <th style="width:22.5%;">Out Loc.</th>
         <!--<th>State</th>
         <th >City</th>
         <th>Position</th>-->
         <th style="width:5%;">Km Trav.</th>
         <th style="width:35%;">Area Vis.</th>
         <th style="width:5%;">Vis.Loc</th>
         <!--<th>Report To</th>-->
      </tr>
   </thead>
   <tbody></tbody>
   <tfoot>
     
      <!--<td></td>-->
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <!--<td></td>
      <td></td>
      <td></td>-->
      <td></td>
      <td></td>
      <!--<td></td>-->
      
   </tfoot>
</table>
</div>
</div>



<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="history_check_in_out2" class="hide reports_fr2">
   <table class="table table-history_check_in_out_report2 scroll-responsive">
    <thead>
      <tr>
         <th>Staff Name</th>
         <th>Date</th>
         <th style="width:20px;">Day On</th>
         <th >Location In</th>
         <th>Location In Name</th>
         <th>Day Off</th>
         <th>Location Out</th>
         <th>Location Out Name</th>
         <th>Km Travelled</th>
         <th>Area Visited</th>
         <th>Visited Location</th>
      </tr>
   </thead>
   <tbody></tbody>
   <tfoot>
      <td></td>
      <td></td>
      <td style="width:20px;"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
   </tfoot>
</table>
</div>

<?php init_head();?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="panel_s">
        <div class="panel-body">
          <?php $arrAtt = array();
                $arrAtt['data-type']='currency';
                ?>
          <?php echo form_open_multipart($this->uri->uri_string(),array('id'=>'contra-entry-form','autocomplete'=>'off')); ?>
          <!--<h4 class="no-margin font-bold"><?php echo _l($title); ?></h4>
          <hr />-->
          <div class="row">
              <?php
            $data_attr = array();
            if(isset($contra_entry)){
                $data_attr = array(
                    "disabled" =>true
                    );
            }
            $data_attr2 = array(
                    "disabled" =>true
                    );
            ?>
            <div class="col-md-4">
              <?php $value = (isset($contra_entry) ? substr($contra_entry->Transdate,0,10) : _d(date('Y-m-d'))); ?>
              <?php echo render_date_input('contra_date','Voucher Date',$value,$data_attr); ?>
              <?php
                if(isset($contra_entry)){
                    ?>
                    <input type="hidden" name="contra_date" value="<?php echo substr($contra_entry->Transdate,0,10); ?>">
                <?php
                }
              ?>
            </div>
            <div class="col-md-4">
                
            <?php
                $selected_company = $this->session->userdata('root_company');
                if($selected_company == 1){
                
                $new_contraNumber = get_option('next_contra_number_for_cspl');
            }elseif($selected_company == 2){
                $new_contraNumber = get_option('next_contra_number_for_cff');
            }elseif($selected_company == 3){
                $new_contraNumber = get_option('next_contra_number_for_cbu');
            }
            ?>
            
              <?php $value = (isset($contra_entry) ? $contra_entry->VoucherID : $new_contraNumber); ?>
              <?php echo render_input('contra_number','Voucher No.',$value,'text',$data_attr2); ?>
            </div>
            <div class="col-md-1" style="margin-top: 20px;">
                
            <?php
                    if(isset($contra_entry)){
                ?>
            <?php
            if (has_permission_new('accounting_contra_entry', '', 'edit')) {
            ?>
               
                <button type="button" class="btn btn-info contra-entry-form-submiter">Update</button>
                <?php
                }
            ?>
                <?php 
                
                    }else{
                ?>
            <?php
            if (has_permission_new('accounting_contra_entry', '', 'create')) {
            ?>
                <button type="button" class="btn btn-info contra-entry-form-submiter" ><?php echo _l('submit'); ?></button>
            <?php
                    }
                ?>    
            <?php
                    }
                ?>
            </div>
            
            <div class="col-md-1" style="margin-top: 20px;">
            <?php
                if (has_permission_new('accounting_contra_entry', '', 'view')) {
            ?>
              <a href="#" class="btn btn-info add-new-transfer mbot15">show list</a>
            <?php
                    }
                ?>  
          </div>
          
          <?php
                    if(isset($contra_entry)){
                ?>
            <div class="col-md-1" style="margin-top: 20px;">
            <?php
                if (has_permission_new('accounting_contra_entry', '', 'delete')) {
            ?>  
              <a href="<?php echo admin_url('accounting/delete_contra_entry/' . $contra_entry->VoucherID) ?>" class="btn btn-info">Delete</a>
            <?php
                    }
                ?>    
          </div>
          <?php
                    }
                ?>
            
          </div>
          <div id="contra_entry_container"></div>
          <div class="col-md-12">
         <table class="table text-right">
            <tbody>
               
               <tr>
                  <td class="text-right bold" style="width: 38%;">Total Debit/Credit Amount</td>
                  <td class="total_debit">
                    <?php $value = (isset($contra_entry) ? $contra_entry->damt : 0); ?>
                    <?php echo app_format_money($value, $currency->name); ?>
                  </td>
                  
                  <td class="total_credit">
                    <?php $value = (isset($contra_entry) ? $contra_entry->camt : 0); ?>
                    <?php echo app_format_money($value, $currency->name); ?>
                  </td>
                  <td style="width: 38%;"></td>
               </tr>
            </tbody>
         </table>
        </div>
          <?php echo form_hidden('contra_entry'); ?>
          <?php echo form_hidden('amount'); ?>
          
          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="transfer-modal" data-keyboard="false" data-backdrop="static">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Contra Voucher List</h4>
         </div>
         <div class="modal-body">
             
            <div class="row">
                <?php $current_date = date('d/m/Y'); 
                $from_date = '01/'.date('m').'/'.date('Y');
                ?>
                <div class="col-md-3">
                    <?php
                   echo render_date_input('from_date','From',$from_date);
                   ?>
                </div>
                <div class="col-md-3">
                    <?php
                   echo render_date_input('to_date','To',$current_date);
                   ?>
                </div>
                <div class="col-md-3">
                    <br>
                    <button class="btn btn-info pull-left mleft5 search_data" id="search_data"><?php echo _l('rate_filter'); ?></button>
                </div>
                <div class="col-md-3">
                    <br>
                    <input type="text" id="myInput1" onkeyup="myFunction2()" placeholder="Search for names.." title="Type in a name" style="float: right;">
                </div>
                <div class="col-md-12">
                 
            <div class="table_contra_report">
             
              <table class="tree table table-striped table-bordered table_contra_report" id="table_contra_report" width="100%">
                  
                <thead>
                    <tr style="display:none;">
                      <td colspan="9" ><h5 style="text-align:center;"><span style="font-size:15px;font-weight:700;"><?php echo $company_detail->company_name; ?></span><br><span style="font-size:10px;font-weight:600;"><?php echo $company_detail->address; ?></span><br><span class="report_for" style="font-size:10px;"></span></h5></td>
                  </tr>
                  <tr>
                    <th style="text-align:left;">VoucherNo</th>
                    <th style="text-align:left;">VoucherDate</th>
                    <th style="text-align:left;">AccountID</th>
                    <th style="text-align:left;">Account Name</th>
                    <th style="text-align:left;">Dr/Cr</th>
                    <th style="text-align:left;">Amount</th>
                    <th style="text-align:left;">Description</th>
                    
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>   
            </div>
            <span id="searchh2" style="display:none;">
                                Loading.....
                            </span>
                    
                </div>
              </div>
              
         </div>
        
      </div>
   </div>
</div>
<style>
    .table_contra_report { overflow: auto;max-height: 60vh;width:100%;position:relative;top: 0px; }
.table_contra_report thead th { position: sticky; top: 0; z-index: 1; }
.table_contra_report tbody th { position: sticky; left: 0; }

/* Just common table stuff. Really. */
.table_contra_report table  { border-collapse: collapse; width: 100%; }
.table_contra_report th, td { padding: 3px 3px !important; white-space: nowrap;font-size:11px; line-height:1.42857143;vertical-align: middle;}
.table_contra_report th     { background: #50607b;color: #fff !important; }


#table_contra_report tr:hover {
    background-color: #ccc;
}

#table_contra_report td:hover {
    cursor: pointer;
}
</style>
<?php init_tail(); ?>
<script type="text/javascript" language="javascript" >
$(document).ready(function(){
 
  function load_data(from_date,to_date)
  {
    $.ajax({
      url:"<?php echo admin_url(); ?>accounting/load_data_for_contra",
      dataType:"JSON",
      method:"POST",
      data:{from_date:from_date, to_date:to_date},
      beforeSend: function () {
               
        $('#searchh2').css('display','block');
        $('.table_contra_report tbody').css('display','none');
        
     },
      complete: function () {
                            
        $('.table_contra_report tbody').css('display','');
        $('#searchh2').css('display','none');
     },
      success:function(data){
        var html = '';
      
        for(var count = 0; count < data.length; count++)
        {
           if(data[count].AccountID == null){
              var new_AccountID = data[count].staff_AccountID;
          }else{
              var new_AccountID = data[count].AccountID;
          }
          var url = "'<?php echo admin_url() ?>accounting/new_contra_entry/"+data[count].VoucherID+"'";
        html += '<tr onclick="location.href='+url+'">';
        html += '<td style="text-align:center;">'+data[count].VoucherID+'</td>';
          
        var date = data[count].Transdate.substring(0, 10)
        var date_new = date.split("-").reverse().join("/");
          
          html += '<td  style="text-align:center;">'+date_new+'</td>';
          
          html += '<td >'+new_AccountID+'</td>';
          if(data[count].AccountName == null){
              var AccoutName = data[count].firstname + data[count].lastname;
          }else{
              var AccoutName = data[count].AccountName;
          }
          html += '<td  style="text-align:left;">'+ AccoutName +'</td>';
          html += '<td  style="text-align:center;">'+data[count].TType+'</td>';
          html += '<td style="text-align:right;">'+data[count].Amount+'</td>';
          html += '<td >'+data[count].Narration+'</td>';
         
          html += '</tr>';
        }
         $('.table_contra_report tbody').html(html);
      
      }
    });
  }
  
 $('#search_data').on('click',function(){
        var from_date = $("#from_date").val();
	    var to_date = $("#to_date").val();
	    var msg = "Sales Report "+from_date +" To " + to_date;
	    $(".report_for").text(msg);
        load_data(from_date,to_date);
        
 });

});
</script>

<script>
    function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("table_contra_report");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[3];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
<script>
    $('.add-new-transfer').on('click', function(){
    $('#transfer-modal').find('button[type="submit"]').prop('disabled', false);
      $('#transfer-modal').modal('show');
      init_journal_entry_table();
    });
</script>
 <script>
    $(document).ready(function(){
    var maxEndDate = new Date('Y/m/d');
    var fin_y = "<?php echo $this->session->userdata('finacial_year')?>";
    
    var year = "20"+fin_y;
    
    
    var cur_y = new Date().getFullYear().toString().substr(-2);
    if(cur_y > fin_y){
        var year2 = parseInt(fin_y) + parseInt(1);
        var year2_new = "20"+year2;
        
        var e_dat = new Date(year2_new+'/03/31');
        var maxEndDate_new = e_dat;
    }else{
         var maxEndDate_new = maxEndDate;
    }
    
    var minStartDate = new Date(year, 03);
   /* console.log(minStartDate);
    console.log(maxEndDate_new);*/
    
    $('#contra_date').datetimepicker({
        format: 'd/m/Y',
        minDate: minStartDate,
        maxDate: maxEndDate_new,
        timepicker: false
    });
    
    
    });
</script> 
</body>
</html>
<?php require 'modules/accounting/assets/js/contra_entry/contra_entry_js.php';?>
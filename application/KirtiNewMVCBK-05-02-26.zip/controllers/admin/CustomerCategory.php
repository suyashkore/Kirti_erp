<?php
	
	defined('BASEPATH') or exit('No direct script access allowed');
	
	class CustomerCategory extends AdminController
	{	
		public function __construct()
		{
			parent::__construct();
		}
		
		/* List all available items */
		public function index()
		{
			$this->load->view('admin/CustomerCategory/manage');
		}
}

<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Territory extends AdminController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data['title'] = 'Territory Master';

        // Sample data for the table
        $data['territories'] = [
            ['id' => 1, 'title' => 'Territory One', 'description' => 'Short description 1', 'date' => '2026-01-01', 'blocked' => 'No'],
            ['id' => 2, 'title' => 'Territory Two', 'description' => 'Short description 2', 'date' => '2026-01-05', 'blocked' => 'No'],
            ['id' => 3, 'title' => 'Territory Three', 'description' => 'Short description 3', 'date' => '2026-01-10', 'blocked' => 'Yes'],
        ];

        $this->load->view('admin/Territory/territory', $data);
    }

    public function manage()
    {
        if ($this->input->post()) {
            $post = $this->input->post();

            // TODO: Persist to DB later

            set_alert('success', 'Territory created successfully');
            redirect(admin_url('territory'));
        }
    }
}

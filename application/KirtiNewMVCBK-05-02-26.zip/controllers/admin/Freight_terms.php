<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Freight_terms extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        // $this->load->model('freight_terms_model');
    }

    public function index()
    {
        $data['title'] = 'Freight Terms Master';
        $data['freight_terms'] = [];
        $this->load->view('admin/freight_terms/freight_terms_form', $data);
    }

    public function manage()
    {
        if ($this->input->post()) {
            // The table 'tblfreight_terms' does not exist.
            // To prevent errors, this functionality is temporarily disabled.
            set_alert('warning', 'Functionality disabled: Database table not found.');
        }
        redirect(admin_url('freight_terms'));
    }

    public function delete($id)
    {
        // The table 'tblfreight_terms' does not exist.
        // To prevent errors, this functionality is temporarily disabled.
        set_alert('warning', 'Functionality disabled: Database table not found.');
        redirect(admin_url('freight_terms'));
    }
    
    public function get_term($id)
    {
        if ($this->input->is_ajax_request()) {
            // The table 'tblfreight_terms' does not exist.
            echo json_encode(null);
        }
    }
}

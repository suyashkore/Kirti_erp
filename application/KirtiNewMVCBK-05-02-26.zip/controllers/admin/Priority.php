<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Priority extends AdminController {

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        $this->load->view('admin/priority/manage.php');
    }

}

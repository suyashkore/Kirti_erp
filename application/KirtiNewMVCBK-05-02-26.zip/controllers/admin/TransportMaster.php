<?php
	defined('BASEPATH') or exit('No direct script access allowed');
	/**
		* This class describes a purchase.
	*/
	class TransportMaster extends AdminController
	{
		public function __construct()	
		{
			parent::__construct();
		}	
		public function index(){
			$this->load->model('clients_model');
			$data['state'] = $this->clients_model->getallstate();
			
			$this->load->model('transport_model');

			$data['countries'] = $this->transport_model->getallcountry();

			$this->load->view('admin/transport/AddEditTransport',$data);	
		}
	}
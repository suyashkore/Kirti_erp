<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Delivery_order extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        // Load necessary models here
    }

    public function index()
    {
        redirect(admin_url('delivery_order/create'));
    }

    public function create()
    {
        $data['title'] = 'Create Delivery Order';

        // Mock data for dropdowns (Replace with database calls)
        $data['plants'] = ['Plant A', 'Plant B'];
        $data['categories'] = ['Category 1', 'Category 2'];
        $data['dispatch_from_list'] = ['Warehouse 1', 'Warehouse 2'];
        $data['consignees'] = ['Consignee A', 'Consignee B'];
        // Load actual customers with Account Code and Account Name
        $this->load->model('clients_model');
        // Use the same customer list method as Clients controller (plant filtered)
        if (method_exists($this->clients_model, 'GetAllCustomerList')) {
            $clients = $this->clients_model->GetAllCustomerList();
        } else {
            $clients = $this->clients_model->get();
        }
        $customers = [];
        if (!empty($clients)) {
            foreach ($clients as $c) {
                $code = isset($c['AccountID']) && $c['AccountID'] != '' ? $c['AccountID'] : (isset($c['userid']) ? $c['userid'] : '');
                $name = '';
                if (isset($c['company']) && $c['company'] != '') {
                    $name = $c['company'];
                } else {
                    $fname = isset($c['firstname']) ? $c['firstname'] : '';
                    $lname = isset($c['lastname']) ? $c['lastname'] : '';
                    $name = trim($fname . ' ' . $lname);
                }
                $customers[] = [
                    'id'    => $code,
                    'label' => trim($code . ' - ' . $name),
                ];
            }
        }
        $data['customers'] = $customers;
        $data['locations'] = ['Location 1', 'Location 2'];
        $data['advance_regular_options'] = ['Advance', 'Regular'];

        // Load the view (init_head() and init_tail() are called within the view)
        $this->load->view('admin/Delivery_order/create', $data);
    }
}

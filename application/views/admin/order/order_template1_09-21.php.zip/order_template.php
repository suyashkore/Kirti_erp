<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!--<div class="panel_s<?php if(!isset($order) || (isset($order) && count($invoices_to_merge) == 0 && (isset($order) && !isset($invoice_from_project) && count($expenses_to_bill) == 0 || $invoice->status == Invoices_model::STATUS_CANCELLED))){echo ' hide';} ?>" id="invoice_top_info">
   <div class="panel-body">
      <div class="row">
         <div id="merge" class="col-md-6">
            <?php
              if(isset($order)){
                 //$this->load->view('admin/invoices/merge_invoice', array('invoices_to_merge'=>$invoices_to_merge));
              }
            ?>
         </div>-->
         <!--  When invoicing from project area the expenses are not visible here because you can select to bill expenses while trying to invoice project -->
         <!--<?php if(!isset($invoice_from_project)){ ?>
           <div id="expenses_to_bill" class="col-md-6">
              <?php if(isset($order) && $order->status != Invoices_model::STATUS_CANCELLED){
                 //$this->load->view('admin/invoices/bill_expenses',array('expenses_to_bill'=>$expenses_to_bill));
              } ?>
           </div>
         <?php } ?>
      </div>
   </div>
</div>-->
<div class="panel_s invoice accounting-template">
   <div class="additional"></div>
   <div class="panel-body">
      <?php if(isset($order)){ ?>
      <?php  echo format_invoice_status($order->status); ?>
      <hr class="hr-panel-heading" />
      <?php } ?>
      <?php hooks()->do_action('before_render_invoice_template'); ?>
      <?php if(isset($order)){
        echo form_hidden('merge_current_invoice',$order->id);
      } ?>
      
    <div class="row">
        <div class="col-md-6">
            
            <?php
            $selected_company = $this->session->userdata('root_company');
            if($selected_company == 1){
                
                $next_order_number = get_option('next_order_number_for_cspl');
            }elseif($selected_company == 2){
                $next_order_number = get_option('next_order_number_for_cff');
            }elseif($selected_company == 3){
                $next_order_number = get_option('next_order_number_for_cbu');
            }
            
            
               //$next_order_number = get_option('next_order_number');
               $format = get_option('invoice_number_format');

               if(isset($order)){
                  $format = $order->number_format;
               }

               //$prefix = get_option('invoice_prefix');
                $prefix = "ORD".date("y");
               if ($format == 1) {
                 $__number = $next_order_number;
                 if(isset($order)){
                   $__number = $order->number;
                   $prefix = '<span id="prefix">ORD</span>';
                 }
               } else if($format == 2) {
                 if(isset($order)){
                   $__number = $order->number;
                   $prefix = $order->prefix;
                   $prefix = '<span id="prefix">'. $prefix . '</span><span id="prefix_year">' .date('Y',strtotime($order->date)).'</span>/';
                 } else {
                  $__number = $next_order_number;
                  $prefix = $prefix.'<span id="prefix_year">'.date('Y').'</span>/';
                }
               } else if($format == 3) {
                  if(isset($order)){
                   $yy = date('y',strtotime($order->date));
                   $__number = $order->number;
                   $prefix = '<span id="prefix">'. $order->prefix . '</span>';
                 } else {
                  $yy = date('y');
                  $__number = $next_order_number;
                }
               } else if($format == 4) {
                  if(isset($order)){
                   $yyyy = date('Y',strtotime($order->date));
                   $mm = date('m',strtotime($order->date));
                   $__number = $order->number;
                   $prefix = '<span id="prefix">'. $order->prefix . '</span>';
                 } else {
                  $yyyy = date('Y');
                  $mm = date('m');
                  $__number = $next_order_number;
                }
               }

               $_is_draft = (isset($order) && $order->status == Invoices_model::STATUS_DRAFT) ? true : false;
               $_invoice_number = str_pad($__number, get_option('number_padding_prefixes'), '0', STR_PAD_LEFT);
               $isedit = isset($order) ? 'true' : 'false';
               $data_original_number = isset($order) ? $order->number : 'false';

               ?>
               <div class="col-md-6">
                   <div class="form-group">
                           <label for="number">
                              <?php echo _l('order_add_edit_number'); ?> 
                             <!--<i class="fa fa-question-circle" data-toggle="tooltip" data-title="<?php echo _l('invoice_number_not_applied_on_draft') ?>" data-placement="top"></i>-->
                        </label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <?php if(isset($order)){ ?>
                                <!--<a href="#" onclick="return false;" data-toggle="popover" data-container='._transaction_form' data-html="true" data-content="<label class='control-label'><?php echo _l('settings_sales_invoice_prefix'); ?></label><div class='input-group'><input name='s_prefix' type='text' class='form-control' value='<?php echo $order->prefix; ?>'></div><button type='button' onclick='save_sales_number_settings(this); return false;' data-url='<?php echo admin_url('invoices/update_number_settings/'.$order->id); ?>' class='btn btn-info btn-block mtop15'><?php echo _l('submit'); ?></button>">
                                <i class="fa fa-cog"></i>
                                </a>-->
                              <?php }
                                echo $prefix;
                              ?>
                              </span>
                              <input type="hidden" value="<?php echo date('y'); ?>" name="years" class="years" id="years">
                              <input type="text" id="ordnumber" name="number1" class="form-control number1" value="<?php echo $_invoice_number; ?>" data-isedit="<?php echo $isedit; ?>" data-original-number="<?php echo $data_original_number; ?>">
                              <?php if($format == 3) { ?>
                              <span class="input-group-addon">
                                 <span id="prefix_year" class="format-n-yy"><?php echo $yy; ?></span>
                              </span>
                              <?php } else if($format == 4) { ?>
                               <span class="input-group-addon">
                                 <span id="prefix_month" class="format-mm-yyyy"><?php echo $mm; ?></span>
                                 /
                                 <span id="prefix_year" class="format-mm-yyyy"><?php echo $yyyy; ?></span>
                              </span>
                              <?php } ?>
                             <div class="input-group-addon search_order">
                                  <i class="fa fa-search calendar-icon"></i>
                              </div>
                           </div>
                        </div>
               </div>
               
               <div class="col-md-6">
                   <input type="hidden" name="number" class="form-control" value="<?php echo ($_is_draft) ? 'DRAFT' : $_invoice_number; ?>" data-isedit="<?php echo $isedit; ?>" data-original-number="<?php echo $data_original_number; ?>" <?php echo ($_is_draft) ? 'disabled' : '' ?>>
                   <?php $value = (isset($order) ? _d($order->date) : _d(date('Y-m-d')));
                  $date_attrs = array();
                  
                    $date_attrs['disabled'] = true;
                  
                  ?>
                  <?php echo render_date_input('date1','invoice_add_edit_date',$value,$date_attrs); ?>
                  
                </div>
                <div class="col-md-12">
                    
                    <div class="f_client_id1">
                        <div class="form-group select-placeholder">
                        <label for="clientid" class="control-label"><?php echo _l('order_select_customer'); ?></label>
                        <select id="clientid" name="clientid" data-live-search="true" data-width="100%" class="ajax-search<?php if(isset($order) && empty($order->clientid)){echo ' customer-removed';} ?>" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
                            <?php $selected = (isset($order) ? $order->clientid : '');
                            if($selected == ''){
                                $selected = (isset($customer_id) ? $customer_id: '');
                            }
                            if($selected != ''){
                                $rel_data = get_relation_data('customer',$selected);
                                $rel_val = get_relation_values($rel_data,'customer');
                                echo '<option value="'.$rel_val['id'].'" selected>'.$rel_val['name'].'</option>';
                            } ?>
                        </select>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-lable" style="margin-top: 7px;">Location</label>
                        </div>
                        
                        <?php //print_r($client_detail);?>
                        <div class="col-md-4">
                            <div class="form-group" style="margin-bottom:5px;">
                             <input type="text" class="form-control" name="location_type" id="location_type" value="<?php echo $client_detail->location_type; ?>" disabled>
                             <input type="hidden" class="form-control" name="location_typevalue" id="location_typevalue" value="<?php echo $client_detail->location_type; ?>">
                             <input type="hidden" class="form-control" name="item_divistion" id="item_divistion" value='<?php echo $client_detail->itemdivision; ?>'>
                             <input type="hidden" class="form-control" name="dist_comp" id="dist_comp" value='<?php echo $client_detail->company_assigned; ?>'>
                             <input type="hidden" class="form-control" name="dist_sale_agent" id="dist_sale_agent" value='<?php echo $client_detail->company_assigned_staff; ?>'>
                             <?php
                             if(isset($order)){
                                ?>
                            <input type="hidden" class="form-control" name="billing_street1" value="<?php echo $client_detail->billing_street; ?>">
                            <input type="hidden" class="form-control"name="billing_city1" value="<?php echo $client_detail->billing_city; ?>">
                            <input type="hidden" class="form-control"name="billing_state1" value="<?php echo $client_detail->billing_state; ?>">
                            <input type="hidden" class="form-control"name="billing_zip1" value="<?php echo $client_detail->billing_zip; ?>">
                            <input type="hidden" class="form-control" name="billing_country1" value="<?php echo $client_detail->billing_country; ?>">
                            <input type="hidden" class="form-control" name="include_shipping" value="1">
                            <input type="hidden" class="form-control" name="show_shipping_on_invoice" value="1">
                            <input type="hidden" class="form-control" name="shipping_street1" value="<?php echo $client_detail->shipping_street; ?>">
                            <input type="hidden" name="shipping_city1" value="<?php echo $client_detail->shipping_city; ?>">
                            <input type="hidden" name="shipping_state1" value="<?php echo $client_detail->shipping_state; ?>">
                            <input type="hidden" name="shipping_zip1" value="<?php echo $client_detail->shipping_zip; ?>">
                            <input type="hidden" name="shipping_country1" value="<?php echo $client_detail->shipping_country; ?>">
                            
                            <?php
                             }
                             ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <?php $billing_street = (isset($order) ? $order->billing_street : '--'); ?>
                     <?php $billing_street = ($billing_street == '' ? '--' :$billing_street); ?>
                            <input type="text" class="form-control" name="dist_street" id="dist_street" value="<?php echo $client_detail->address; ?>" disabled>
                            <input type="hidden" class="form-control" name="dist_route" id="dist_route" value='<?php echo $client_detail->routes; ?>' >
                            <input type="hidden" class="form-control" name="dist_tcs" id="dist_tcs" value="" >
                        </div>
                        <div class="col-md-12">
                            </br>
                            <p style="color:#3826d3 !important;font-size: 16px;font-weight: 600;" class="item_added_msg" id="item_added_msg"></p>
                        </div>
                        
                    </div>
                </div>
                <!--<div class="col-md-12">
                    <div class="row">
                        <div class="col-md-2">
                            <label class="control-lable" style="margin-top: 2px;"><?php echo _l('dispatch_loc'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group" style="margin-bottom:5px;">
                             <select name="dispatch_loc" id="dispatch_loc" class="selectpicker" data-live-search="true" required data-width="100%">
                                 
                                 <option>Select Company</option>
                                 <?php
                                 foreach($rootcompany as $comp){
                                     ?>
                                     <option value="<?php echo $comp["id"];?>"><?php echo $comp["company_name"];?></option>
                                <?php } ?>
                             </select>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>-->
               
        </div>
        
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group" style="margin-bottom:5px;">
                        <?php $acct_bal = (isset($order) ? $order->acct_bal : '--'); ?>
                        <?php $acct_bal = ($acct_bal == '' ? '--' :$acct_bal); ?>
                        <label for="act_bal" class="control-label">A/C Balance</label>
                        <input type="text" class="form-control" name="acct_bal" id="acct_bal" value="<?php echo $acct_bal; ?>" disabled>
                    </div>
                    
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3">
                            
                            <label class="control-label" style="margin-top: 10px;">Last Billed On</label>
                            <?php //echo render_date_input('date','last_bill',$value,$date_attrs); ?>
                            <!--<input type="date" class="form-control" name="last_bill" id="last_bill" value="<?php echo $last_bill; ?>">-->
                           
                        </div>
                        <div class="col-md-5">
                            <?php $last_bill = (isset($order) ? $order->last_bill : ' '); ?>
                            <?php $last_bill = ($last_bill == '' ? '--' :$last_bill); ?>
                    
                            <?php $value = (isset($order) ? _d($order->date) : ' ');
                            $date_attrs = array();
                            $date_attrs['disabled'] = true;
                            ?>
                           <input type="text" class="form-control " name="last_bill" id="last_bill" value="<?php echo $value; ?>" disabled> 
                        </div>
                        <div class="col-md-4">
                            <div class="form-group" style="margin-bottom:5px;">
                                
                                <input type="text" class="form-control" name="last_bill" id="last_bill" value="<?php echo $last_bill; ?>" disabled>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="control-label" style="margin-top: 10px;">Last Deposit</label>
                        </div>
                        <div class="col-md-5">
                            <?php $last_dep = (isset($order) ? $order->last_dep : ' '); ?>
                            <?php $last_dep = ($last_dep == '' ? '--' :$last_dep); ?>
                    
                            <?php $value = (isset($order) ? _d($order->date) : " ");
                            $date_attrs = array();
                            $date_attrs['disabled'] = true;
                            ?>
                           
                            <input type="text" class="form-control " name="last_dep" id="last_dep" value="<?php echo $value; ?>" disabled>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group" style="margin-bottom:5px;">
                                
                                <input type="text" class="form-control" name="last_dep" id="last_dep" value="<?php echo $last_dep; ?>" disabled>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="control-label" style="margin-top: 10px;"><?php echo _l('customer_type'); ?></label>
                        </div>
                        <div class="col-md-9">
                            <div class="form-group" style="margin-bottom:5px;">
                                <input type="text" class="form-control" name="customer_group" id="customer_group" value="<?php echo $customer_groups_name->name." - ".$client_detail->billing_city; ?>" placeholder="Distributor Type" disabled>
                                <input type="hidden" name="customer_group_id" id="customer_group_id" value="<?php echo $customer_groups_name->id; ?>" >
                                <input type="hidden" name="customer_state_id" id="customer_state_id" value="<?php echo $client_detail->state?>" >
                            </div>
                            
                        </div>
                    </div>
                    
                    
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="control-label" style="margin-top: 10px;">Order Type - </label>
                        </div>
                        <div class="col-md-2">
                            <?php $order_type = (isset($order) ? $order->order_type : 'Web'); ?>
                            <?php //$order_type = ($order_type == '' ? 'Web' :$order_type); ?>
                            <p style="color:#3826d3 !important;margin-top: 10px;font-size: 15px;font-weight: 600;"><?php echo $order_type; ?></p>
                            <input type="hidden" class="form-control" name="order_type" id="order_type" value="<?php echo $order_type; ?>">
                        </div>
                        <div class="col-md-7">
                            <?php $taxable = (isset($order) ? $order->taxes : ''); ?>
                            <input type="text" class="form-control" name="tax" id="tax" value="<?php echo $taxable; ?>"  disabled>
                            <input type="hidden" class="form-control" name="taxes" id="taxes" value="<?php echo $taxable; ?>">
                        </div>
                    </div>
                    
                    
                </div>
                
                
                
            </div>
        </div>
        
    </div>
        <div class="row">
            
            <div class="col-md-6">
            
                
            
            
            <?php
            if(!isset($invoice_from_project)){ ?>
            <div class="form-group select-placeholder projects-wrapper<?php if((!isset($order)) || (isset($order) && !customer_has_projects($order->clientid))){ echo ' hide';} ?>">
               <label for="project_id"><?php echo _l('project'); ?></label>
              <div id="project_ajax_search_wrapper">
                   <select name="project_id" id="project_id" class="projects ajax-search" data-live-search="true" data-width="100%" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
                   <?php
                     if(isset($order) && $order->project_id != 0){
                        echo '<option value="'.$order->project_id.'" selected>'.get_project_name_by_id($order->project_id).'</option>';
                     }
                   ?>
               </select>
               </div>
            </div>
            <?php } ?>
            
            <div class="row">
               
               <div class="col-md-6">
                     
                </div>
               <!--<div class="col-md-6">
                  <?php
                  $value = '';
                  if(isset($order)){
                    $value = _d($order->duedate);
                  } else {
                    if(get_option('invoice_due_after') != 0){
                        $value = _d(date('Y-m-d', strtotime('+' . get_option('invoice_due_after') . ' DAY', strtotime(date('Y-m-d')))));
                    }
                  }
                   ?>
                  <?php echo render_date_input('duedate','invoice_add_edit_duedate',$value); ?>
               </div>-->
            </div>
            
            <div class="row">
               <div class="col-md-12">
               <!--<hr class="hr-10" />-->
                  <!--<a href="#" class="edit_shipping_billing_info" data-toggle="modal" data-target="#billing_and_shipping_details"><i class="fa fa-pencil-square-o"></i></a>-->
                  <?php include_once(APPPATH .'views/admin/order/billing_and_shipping_template.php'); ?>
               </div>
            </div>
            
            </div>
            
           <!-- <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                       <p class="bold"><?php echo _l('invoice_bill_to'); ?></p>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <?php $billing_street = (isset($order) ? $order->billing_street : '--'); ?>
                     <?php $billing_street = ($billing_street == '' ? '--' :$billing_street); ?>
                     
                     <textarea class="form-control billing_street" name="billing_street" id="billing_street" rows="3"><?php echo strip_tags($billing_street); ?></textarea>
                      </div>
                      <p class="bold"><?php echo _l('ship_to'); ?></p>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                <?php $billing_city = (isset($order) ? $order->billing_city : '--'); ?>
                                <?php $billing_city = ($billing_city == '' ? '--' :$billing_city); ?>
                                <input type="text" class="form-control" name="billing_city" id="billing_city" value="<?php echo $billing_city; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                             <?php $billing_state = (isset($order) ? $order->billing_state : '--'); ?>
                             <?php $billing_state = ($billing_state == '' ? '--' :$billing_state); ?>
                               <input type="text" class="form-control" name="billing_state" id="billing_state" value="<?php echo $billing_state; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                 <?php $billing_country = (isset($order) ? get_country_short_name($order->billing_country) : '--'); ?>
                                <?php $billing_country = ($billing_country == '' ? '--' :$billing_country); ?>
                                <input type="text" class="form-control" name="billing_country" id="billing_country" value="<?php echo $billing_country; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                             <?php $billing_zip = (isset($order) ? $order->billing_zip : '--'); ?>
                            <?php $billing_zip = ($billing_zip == '' ? '--' :$billing_zip); ?>
                               <input type="text" class="form-control" name="billing_zip" id="billing_zip" value="<?php echo $billing_zip; ?>">
                            </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    
                    
                    <div class="col-md-6">
                        <div class="form-group">
                        <?php $shipping_street = (isset($order) ? $order->shipping_street : '--'); ?>
                     <?php $shipping_street = ($shipping_street == '' ? '--' :$shipping_street); ?>
                     
                     <textarea class="form-control shipping_street" name="shipping_street" id="shipping_street" rows="3"><?php echo strip_tags($shipping_street); ?></textarea>
                      </div>
                      
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                <?php $shipping_city = (isset($order) ? $order->shipping_city : '--'); ?>
                                <?php $shipping_city = ($shipping_city == '' ? '--' :$shipping_city); ?>
                                <input type="text" class="form-control" name="shipping_city" id="shipping_city" value="<?php echo $shipping_city; ?>">
                                </div> 
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                             <?php $shipping_state = (isset($order) ? $order->shipping_state : '--'); ?>
                             <?php $shipping_state = ($shipping_state == '' ? '--' :$shipping_state); ?>
                               <input type="text" class="form-control" name="shipping_state" id="shipping_state" value="<?php echo $shipping_state; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                 <?php $shipping_country = (isset($order) ? get_country_short_name($order->shipping_country) : '--'); ?>
                                <?php $shipping_country = ($shipping_country == '' ? '--' :$shipping_country); ?>
                                <input type="text" class="form-control" name="shipping_country" id="shipping_country" value="<?php echo $shipping_country; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                             <?php $shipping_zip = (isset($order) ? $order->shipping_zip : '--'); ?>
                            <?php $shipping_zip = ($shipping_zip == '' ? '--' :$shipping_zip); ?>
                               <input type="text" class="form-control" name="shipping_zip" id="shipping_zip" value="<?php echo $shipping_zip; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
                
            </div>-->
        </div>
        
        
            
            <!--<div class="row">
               <div class="col-md-12">
               <hr class="hr-10" />
                  <a href="#" class="edit_shipping_billing_info" data-toggle="modal" data-target="#billing_and_shipping_details"><i class="fa fa-pencil-square-o"></i></a>
                  <?php include_once(APPPATH .'views/admin/invoices/billing_and_shipping_template.php'); ?>
               </div>
               <div class="col-md-6">
                  <p class="bold"><?php echo _l('invoice_bill_to'); ?></p>
                  <address>
                     <span class="billing_street">
                     <?php $billing_street = (isset($order) ? $order->billing_street : '--'); ?>
                     <?php $billing_street = ($billing_street == '' ? '--' :$billing_street); ?>
                     <?php echo $billing_street; ?></span><br>
                     <span class="billing_city">
                     <?php $billing_city = (isset($order) ? $order->billing_city : '--'); ?>
                     <?php $billing_city = ($billing_city == '' ? '--' :$billing_city); ?>
                     <?php echo $billing_city; ?></span>,
                     <span class="billing_state">
                     <?php $billing_state = (isset($order) ? $order->billing_state : '--'); ?>
                     <?php $billing_state = ($billing_state == '' ? '--' :$billing_state); ?>
                     <?php echo $billing_state; ?></span>
                     <br/>
                     <span class="billing_country">
                     <?php $billing_country = (isset($order) ? get_country_short_name($order->billing_country) : '--'); ?>
                     <?php $billing_country = ($billing_country == '' ? '--' :$billing_country); ?>
                     <?php echo $billing_country; ?></span>,
                     <span class="billing_zip">
                     <?php $billing_zip = (isset($order) ? $order->billing_zip : '--'); ?>
                     <?php $billing_zip = ($billing_zip == '' ? '--' :$billing_zip); ?>
                     <?php echo $billing_zip; ?></span>
                  </address>
               </div>
                  
               <div class="col-md-6">
                  <p class="bold"><?php echo _l('ship_to'); ?></p>
                  <address>
                     <span class="shipping_street">
                     <?php $shipping_street = (isset($order) ? $order->shipping_street : '--'); ?>
                     <?php $shipping_street = ($shipping_street == '' ? '--' :$shipping_street); ?>
                     <?php echo $shipping_street; ?></span><br>
                     <span class="shipping_city">
                     <?php $shipping_city = (isset($order) ? $order->shipping_city : '--'); ?>
                     <?php $shipping_city = ($shipping_city == '' ? '--' :$shipping_city); ?>
                     <?php echo $shipping_city; ?></span>,
                     <span class="shipping_state">
                     <?php $shipping_state = (isset($order) ? $order->shipping_state : '--'); ?>
                     <?php $shipping_state = ($shipping_state == '' ? '--' :$shipping_state); ?>
                     <?php echo $shipping_state; ?></span>
                     <br/>
                     <span class="shipping_country">
                     <?php $shipping_country = (isset($order) ? get_country_short_name($order->shipping_country) : '--'); ?>
                     <?php $shipping_country = ($shipping_country == '' ? '--' :$shipping_country); ?>
                     <?php echo $shipping_country; ?></span>,
                     <span class="shipping_zip">
                     <?php $shipping_zip = (isset($order) ? $order->shipping_zip : '--'); ?>
                     <?php $shipping_zip = ($shipping_zip == '' ? '--' :$shipping_zip); ?>
                     <?php echo $shipping_zip; ?></span>
                  </address>
               </div>
            </div>-->
            
            
            <div class="row" style="display:none;">
                
                <?php
                        $currency_attr = array('disabled'=>true,'data-show-subtext'=>true,);
                        $currency_attr = apply_filters_deprecated('invoice_currency_disabled', [$currency_attr], '2.3.0', 'invoice_currency_attributes');

                        foreach($currencies as $currency){
                         if($currency['isdefault'] == 1){
                           $currency_attr['data-base'] = $currency['id'];
                         }
                         if(isset($order)){
                          if($currency['id'] == $order->currency){
                           $selected = $currency['id'];
                         }
                        } else {
                         if($currency['isdefault'] == 1){
                           $selected = $currency['id'];
                         }
                        }
                        }
                        $currency_attr = hooks()->apply_filters('invoice_currency_attributes',$currency_attr);
                        
                        ?>
                <?php echo render_select('currency', $currencies, array('id','name','symbol'), 'invoice_add_edit_currency', $selected, $currency_attr); ?>
                <div class="col-md-3">
                    <input type="hidden" name="currency" value="<?php echo $selected; ?>">
                    <?php
                        $i = 0;
                        $selected = '';
                        foreach($staff as $member){
                         if(isset($order)){
                           if($order->sale_agent == $member['staffid']) {
                             $selected = $member['staffid'];
                           }
                         }
                         $i++;
                        }
                        echo render_select('sale_agent',$staff,array('staffid',array('firstname','lastname')),'sale_agent_string',$selected);
                        ?>
                </div>
                <!--<div class="col-md-3">
                    <div class="form-group select-placeholder"<?php if(isset($order) && !empty($order->is_recurring_from)){ ?> data-toggle="tooltip" data-title="<?php echo _l('create_recurring_from_child_error_message', [_l('invoice_lowercase'),_l('invoice_lowercase'), _l('invoice_lowercase')]); ?>"<?php } ?>>
                        <label for="recurring" class="control-label">
                        <?php echo _l('invoice_add_edit_recurring'); ?>
                        </label>
                        <select class="selectpicker"
                        data-width="100%"
                        name="recurring"
                        data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>"
                        <?php
                        // The problem is that this invoice was generated from previous recurring invoice
                        // Then this new invoice you set it as recurring but the next invoice date was still taken from the previous invoice.
                        if(isset($order) && !empty($order->is_recurring_from)){echo 'disabled';} ?>
                        >
                           <?php for($i = 0; $i <=12; $i++){ ?>
                           <?php
                              $selected = '';
                              if(isset($order)){
                                if($order->custom_recurring == 0){
                                 if($order->recurring == $i){
                                   $selected = 'selected';
                                 }
                               }
                              }
                              if($i == 0){
                               $reccuring_string =  _l('invoice_add_edit_recurring_no');
                              } else if($i == 1){
                               $reccuring_string = _l('invoice_add_edit_recurring_month',$i);
                              } else {
                               $reccuring_string = _l('invoice_add_edit_recurring_months',$i);
                              }
                              ?>
                           <option value="<?php echo $i; ?>" <?php echo $selected; ?>><?php echo $reccuring_string; ?></option>
                           <?php } ?>
                           <option value="custom" <?php if(isset($order) && $order->recurring != 0 && $order->custom_recurring == 1){echo 'selected';} ?>><?php echo _l('recurring_custom'); ?></option>
                        </select>
                     </div>
                </div>-->
                <!--<div class="col-md-3">
                    <div class="form-group select-placeholder">
                        <label for="discount_type" class="control-label"><?php echo _l('discount_type'); ?></label>
                        <select name="discount_type" class="selectpicker" data-width="100%" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
                           <option value="" selected><?php echo _l('no_discount'); ?></option>
                           <option value="before_tax" <?php
                              if(isset($order)){ if($order->discount_type == 'before_tax'){ echo 'selected'; }} ?>><?php echo _l('discount_type_before_tax'); ?></option>
                           <option value="after_tax" <?php if(isset($order)){if($order->discount_type == 'after_tax'){echo 'selected';}} ?>><?php echo _l('discount_type_after_tax'); ?></option>
                        </select>
                     </div>
                </div>-->
            </div>
            
           
            <div class="row">
            
                <?php if(is_invoices_overdue_reminders_enabled()){ ?>
               <!--<div class="form-group">
                  <div class="checkbox checkbox-danger">
                     <input type="checkbox" <?php if(isset($order) && $order->cancel_overdue_reminders == 1){echo 'checked';} ?> id="cancel_overdue_reminders" name="cancel_overdue_reminders">
                     <label for="cancel_overdue_reminders"><?php echo _l('cancel_overdue_reminders_invoice') ?></label>
                  </div>
               </div>-->
               <?php } ?>
               <?php $rel_id = (isset($order) ? $order->id : false); ?>
               <?php
                  if(isset($custom_fields_rel_transfer)) {
                      $rel_id = $custom_fields_rel_transfer;
                  }
               ?>
               <?php echo render_custom_fields('invoice',$rel_id); ?>
         </div>
         
            <div class="row">
                
                  <div class="col-md-6">
                     
                  </div>
                  <div class="recurring_custom <?php if((isset($order) && $order->custom_recurring != 1) || (!isset($order))){echo 'hide';} ?>">
                     <div class="col-md-6">
                        <?php $value = (isset($order) && $order->custom_recurring == 1 ? $order->recurring : 1); ?>
                        <?php echo render_input('repeat_every_custom','',$value,'number',array('min'=>1)); ?>
                     </div>
                     <div class="col-md-6">
                        <select name="repeat_type_custom" id="repeat_type_custom" class="selectpicker" data-width="100%" data-none-selected-text="<?php echo _l('dropdown_non_selected_tex'); ?>">
                           <option value="day" <?php if(isset($order) && $order->custom_recurring == 1 && $order->recurring_type == 'day'){echo 'selected';} ?>><?php echo _l('invoice_recurring_days'); ?></option>
                           <option value="week" <?php if(isset($order) && $order->custom_recurring == 1 && $order->recurring_type == 'week'){echo 'selected';} ?>><?php echo _l('invoice_recurring_weeks'); ?></option>
                           <option value="month" <?php if(isset($order) && $order->custom_recurring == 1 && $order->recurring_type == 'month'){echo 'selected';} ?>><?php echo _l('invoice_recurring_months'); ?></option>
                           <option value="year" <?php if(isset($order) && $order->custom_recurring == 1 && $order->recurring_type == 'year'){echo 'selected';} ?>><?php echo _l('invoice_recurring_years'); ?></option>
                        </select>
                     </div>
                  </div>
                  <div id="cycles_wrapper" class="<?php if(!isset($order) || (isset($order) && $order->recurring == 0)){echo ' hide';}?>">
                     <div class="col-md-12">
                        <?php $value = (isset($order) ? $order->cycles : 0); ?>
                        <div class="form-group recurring-cycles">
                          <label for="cycles"><?php echo _l('recurring_total_cycles'); ?>
                            <?php if(isset($order) && $order->total_cycles > 0){
                              echo '<small>' . _l('cycles_passed', $order->total_cycles) . '</small>';
                            }
                            ?>
                          </label>
                          <div class="input-group">
                            <input type="number" class="form-control"<?php if($value == 0){echo ' disabled'; } ?> name="cycles" id="cycles" value="<?php echo $value; ?>" <?php if(isset($order) && $order->total_cycles > 0){echo 'min="'.($order->total_cycles).'"';} ?>>
                            <div class="input-group-addon">
                              <div class="checkbox">
                                <input type="checkbox"<?php if($value == 0){echo ' checked';} ?> id="unlimited_cycles">
                                <label for="unlimited_cycles"><?php echo _l('cycles_infinity'); ?></label>
                              </div>
                            </div>
                          </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--<?php $value = (isset($order) ? $order->adminnote : ''); ?>
               <?php echo render_textarea('adminnote','invoice_add_edit_admin_note',$value); ?>-->
            <div class="row">
         <div class="col-md-4">
            <?php //$this->load->view('admin/invoice_items/item_select'); ?>
         </div>
         <!--<?php if(!isset($invoice_from_project) && isset($billable_tasks)){
          ?>
         <div class="col-md-3">
            <div class="form-group select-placeholder input-group-select form-group-select-task_select popover-250">
              <div class="input-group input-group-select">
               <select name="task_select" data-live-search="true" id="task_select" class="selectpicker no-margin _select_input_group" data-width="100%" data-none-selected-text="<?php echo _l('bill_tasks'); ?>">
                  <option value=""></option>
                  <?php foreach($billable_tasks as $task_billable){ ?>
                  <option value="<?php echo $task_billable['id']; ?>"<?php if($task_billable['started_timers'] == true){ ?>disabled class="text-danger important" data-subtext="<?php echo _l('invoice_task_billable_timers_found'); ?>" <?php } else {
                     $task_rel_data = get_relation_data($task_billable['rel_type'],$task_billable['rel_id']);
                     $task_rel_value = get_relation_values($task_rel_data,$task_billable['rel_type']);
                     ?>
                     data-subtext="<?php echo $task_billable['rel_type'] == 'project' ? '' : $task_rel_value['name']; ?>" <?php } ?>><?php echo $task_billable['name']; ?></option>
                  <?php } ?>
               </select>
                <div class="input-group-addon input-group-addon-bill-tasks-help">
                  <?php
                    if(isset($order) && !empty($order->project_id)) {
                       $help_text = _l('showing_billable_tasks_from_project') . ' ' . get_project_name_by_id($order->project_id);
                    } else {
                       $help_text = _l('invoice_task_item_project_tasks_not_included');
                    }
                    echo '<span class="pointer popover-invoker" data-container=".form-group-select-task_select"
                      data-trigger="click" data-placement="top" data-toggle="popover" data-content="'.$help_text.'">
                      <i class="fa fa-question-circle"></i></span>';
                  ?>
                </div>
               </div>
            </div>
         </div>
         <?php } ?>-->
        <!-- <div class="col-md-<?php if(!isset($invoice_from_project)){ echo 5; }else {echo 8;} ?> text-right show_quantity_as_wrapper">
            <div class="mtop10">
               <span><?php echo _l('show_quantity_as'); ?> </span>
               <div class="radio radio-primary radio-inline">
                  <input type="radio" value="1" id="sq_1" name="show_quantity_as" data-text="<?php echo _l('invoice_table_quantity_heading'); ?>" <?php if(isset($order) && $order->show_quantity_as == 1){echo 'checked';}else if(!isset($hours_quantity) && !isset($qty_hrs_quantity)){echo'checked';} ?>>
                  <label for="sq_1"><?php echo _l('quantity_as_qty'); ?></label>
               </div>
               <div class="radio radio-primary radio-inline">
                  <input type="radio" value="2" id="sq_2" name="show_quantity_as" data-text="<?php echo _l('invoice_table_hours_heading'); ?>" <?php if(isset($order) && $order->show_quantity_as == 2 || isset($hours_quantity)){echo 'checked';} ?>>
                  <label for="sq_2"><?php echo _l('quantity_as_hours'); ?></label>
               </div>
               <div class="radio radio-primary radio-inline">
                  <input type="radio" value="3" id="sq_3" name="show_quantity_as" data-text="<?php echo _l('invoice_table_quantity_heading'); ?>/<?php echo _l('invoice_table_hours_heading'); ?>" <?php if(isset($order) && $order->show_quantity_as == 3 || isset($qty_hrs_quantity)){echo 'checked';} ?>>
                  <label for="sq_3"><?php echo _l('invoice_table_quantity_heading'); ?>/<?php echo _l('invoice_table_hours_heading'); ?></label>
               </div>
            </div>
         </div>-->
         <!--<div class="col-md-6">
             
             <input type="text" id="autouser" name="autouser" class="form-control" placeholder="<?php echo _l('item_code'); ?>">
         </div>-->
      </div>
      <?php if(isset($invoice_from_project)){ echo '<hr class="no-mtop" />'; } ?>
      <div class="table-responsive s_table">
        
         <table class="table invoice-items-table items table-main-invoice-edit has-calculations no-mtop">
            <thead>
               <tr>
                  <th></th>
                  <th  width="10%" align="left"><?php echo _l('item_code'); ?></th>
                  <th width="35%" align="left"><i class="fa fa-exclamation-circle" aria-hidden="true" data-toggle="tooltip" data-title="<?php echo _l('item_description_new_lines_notice'); ?>"></i> <?php echo _l('order_table_item_heading'); ?></th>
                  <th width="5%" align="left"><?php echo _l('cs_cr'); ?></th>
                  <th width="10%" align="left"><?php echo _l('pack_qty'); ?></th>
                  <?php
                  /*$custom_fields = get_custom_fields('items');
                  foreach($custom_fields as $cf){
                    echo '<th width="15%" align="left" class="custom_field">' . $cf['name'] . '</th>';
                  }*/
                     $qty_heading = _l('order_table_quantity_heading');
                     if(isset($order) && $order->show_quantity_as == 2 || isset($hours_quantity)){
                      $qty_heading = _l('invoice_table_hours_heading');
                     } else if(isset($order) && $order->show_quantity_as == 3){
                      $qty_heading = _l('invoice_table_quantity_heading') .'/'._l('invoice_table_hours_heading');
                     }
                     ?>
                  <th width="10%" align="left" class="qty"><?php echo $qty_heading; ?></th>
                  <th width="5%" align="left"><?php echo _l('invoice_table_rate_heading'); ?></th>
                  <th width="5%" align="left"><?php echo _l('order_table_dis'); ?></th>
                  <th width="5%" align="left"><?php echo _l('order_table_dis_amt'); ?></th>
                 <!-- <th width="5%" align="left"><?php echo _l('order_table_tax_heading'); ?></th>-->
                  <th width="10%" align="left"><?php echo _l('order_table_tax_heading'); ?></th>
                  <th width="10%" align="left"><?php echo _l('invoice_table_amount_heading'); ?></th>
                  <th align="center"><i class="fa fa-cog"></i></th>
               </tr>
            </thead>
            <?php
            if($order->order_type == "Mobile")
                    {
                        $tt = "disabled";
                    }else {
                        $tt = " ";
                    }
            ?>
            <tbody>
                <?php
            if($order->order_type == "Mobile") { } else { ?>
               <tr class="main">
                  <td></td>
                  <td><input type="text" name="item_code" id="item_code" class="form-control">
                  <div class="" id="serchh" style="display:none;">Serching</div>
                  <input type="hidden" name="hsn_code" class="form-control"></td>
                  <td>
                     <!--<textarea name="description" class="form-control" rows="4" placeholder="<?php echo _l('item_description_placeholder'); ?>"></textarea>-->
                    
                    <input type="text" id="autouser" name="autouser" class="form-control" placeholder="item name" <?php echo $tt; ?>>
                  </td>
                  <td>
                     <!--<textarea name="long_description" rows="4" class="form-control" placeholder="<?php echo _l('item_long_description_placeholder'); ?>"></textarea>-->
                    <input type="text" name="items_case_qty" class="form-control" placeholder="" disabled>
                    
                  </td>
                  <td>
                     <!--<textarea name="long_description" rows="4" class="form-control" placeholder="<?php echo _l('item_long_description_placeholder'); ?>"></textarea>-->
                    <input type="number" name="pack_qty" class="form-control" placeholder="" disabled>
                  </td>
                  <?php //echo render_custom_fields_items_table_add_edit_preview(); ?>
                  <td>
                     <input type="text" name="quantity" id="quantity"  value="" class="form-control" onblur="add_item_to_table1('undefined','undefined',<?php echo $new_item; ?>); return false;" <?php echo $tt; ?>>
                     <!--<input type="text" placeholder="<?php echo _l('unit'); ?>" data-toggle="tooltip" data-title="e.q kg, lots, packs" name="unit" class="form-control input-transparent text-right">-->
                  </td>
                  <td>
                     <input type="text" name="rate" class="form-control" placeholder="" disabled>
                  </td>
                  <td>
                     <input type="text" name="dis" class="form-control" placeholder="" disabled>
                  </td>
                  <td>
                     <input type="text" name="dis_amt" class="form-control" placeholder="" disabled>
                     <input type="hidden" name="taxrate1" class="form-control" placeholder="" disabled>
                  </td>
                  <!--<td>
                     <input type="text" name="taxname" class="form-control" placeholder="<?php echo _l('no_tax'); ?>" disabled>
                  </td>-->
                 <td>
                     <?php
                        $default_tax = unserialize(get_option('default_tax'));
                        $select = '<select class="selectpicker display-block tax main-tax" data-width="100%" name="taxname" id="taxname" multiple data-none-selected-text="" disabled>';
                      //  $select .= '<option value=""'.(count($default_tax) == 0 ? ' selected' : '').'>'._l('no_tax').'</option>';
                        foreach($taxes as $tax){
                        $selected = '';
                         if(is_array($default_tax)){
                             if(in_array($tax['name'] . '|' . $tax['taxrate'],$default_tax)){
                                  $selected = ' selected ';
                             }
                        }
                        $select .= '<option value="'.$tax['name'].'|'.$tax['taxrate'].'"'.$selected.'data-taxrate="'.$tax['taxrate'].'" data-taxname="'.$tax['name'].'" data-subtext="'.$tax['name'].'">'.$tax['taxrate'].'%</option>';
                        }
                        $select .= '</select>';
                        echo $select;
                        ?>
                        <!--<input type="text" name="taxname" class="form-control" placeholder="<?php echo _l('no_tax'); ?>" disabled>-->
                  </td>
                  <td></td>
                  <td>
                     <?php
                        $new_item = 'undefined';
                        if(isset($order)){
                         $new_item = true;
                        }
                        ?>
                     <!--<button type="button" onclick="add_item_to_table1('undefined','undefined',<?php echo $new_item; ?>); return false;" class="btn pull-right btn-info"><i class="fa fa-check"></i></button>-->
                  </td>
               </tr>
               <?php } ?>
               <?php if (isset($order) || isset($add_items)) {
                  $i               = 1;
                  $items_indicator = 'newitems';
                  if (isset($order)) {
                    $add_items       = $order->items;
                    $items_indicator = 'items';
                  }
                  foreach ($add_items as $item) {

                    $manual    = false;
                    $table_row = '<tr class="sortable item">';
                    $table_row .= '<td class="dragger">';
                    if (!is_numeric($item['qty'])) {
                      $item['qty'] = 1;
                    }
                    $invoice_item_taxes = get_invoice_item_taxes($item['id']);
                    // passed like string
                    if ($item['id'] == 0) {
                        $invoice_item_taxes = $item['taxname'];
                        $manual             = true;
                    }
                    $table_row .= form_hidden('' . $items_indicator . '[' . $i . '][itemid]', $item['id']);
                    $amount = $item['rate'] * $item['qty'];
                    $amount = app_format_number($amount);
                    $code_placeholder = "Item Code";
                   
                    $table_row .= '<input type="hidden" class="order" name="' . $items_indicator . '[' . $i . '][order]">';
                    $table_row .= '</td>';
                    $table_row .= '<td><input type="text" placeholder="'.$code_placeholder.'" name="'.$items_indicator.'['.$i.'][item_code]" class="form-control" value="'.$item['item_code'].'" disabled><input type="hidden" name="'.$items_indicator.'['.$i.'][item_code1]" value="'.$item['item_code'].'"><input type="hidden" name="'.$items_indicator.'['.$i.'][hsn_code]" value="'.$item['hsn_code'].'"></td>';
                    $table_row .= '<td class="bold description"><input name="' . $items_indicator . '[' . $i . '][description]" class="form-control" value="'.$item['description'].'" '. $tt .'></td>';
                    $table_row .= '<td><input name="' . $items_indicator . '[' . $i . '][items_case_qty]" class="form-control"  value="" disabled><input type="hidden" name="' . $items_indicator . '[' . $i . '][cs_cr]" value=""></td>';
                    $table_row .= '<td class="pack_qty"><input name="' . $items_indicator . '[' . $i . '][pack_qty1]" class="form-control" value="'.$item['pack_qty'].'" disabled><input type="hidden" name="' . $items_indicator . '[' . $i . '][pack_qty]" value="'.$item['pack_qty'].'"></td>';
                    //$table_row .= render_custom_fields_items_table_in($item,$items_indicator.'['.$i.']');
                    
                    $table_row .= '<td class="order_qty"><input type="number" min="0" onblur="calculate_total();" onchange="calculate_total();" data-quantity name="' . $items_indicator . '[' . $i . '][qty]" value="' . $item['qty'] . '" class="form-control" '.$tt.'>';

                    // order input
                     $unit_placeholder = '';
                    if(!$item['unit']){
                      $unit_placeholder = _l('unit');
                      $item['unit'] = '';
                    }

                    //$table_row .= '<input type="text" placeholder="'.$unit_placeholder.'" name="'.$items_indicator.'['.$i.'][unit]" class="form-control input-transparent text-right" value="'.$item['unit'].'">';

                    $table_row .= '</td>';
                    $table_row .= '<td class="rate"><input type="number"  onblur="calculate_total();" onchange="calculate_total();" name="' . $items_indicator . '[' . $i . '][rate1]" value="' . $item['rate'] . '" class="form-control" disabled> <input type="hidden" name="' . $items_indicator . '[' . $i . '][rate]" value="' . $item['rate'] . '"></td>';
                    $table_row .= '<td><input name="' . $items_indicator . '[' . $i . '][dis]" class="form-control"  value="'.$item['pack_qty'].'" disabled></td>';
                    $table_row .= '<td><input name="' . $items_indicator . '[' . $i . '][dis_amt]" class="form-control"  value="'.$item['discount_amt'].'" disabled><input type="hidden" name="' . $items_indicator . '[' . $i . '][dis_amt1]" value="'.$item['discount_amt'].'"></td>';
                    //$table_row .= '<td class="taxrate">' . $this->misc_model->get_taxes_dropdown_template('' . $items_indicator . '[' . $i . '][taxname][]', $invoice_item_taxes, 'invoice', $item['id'], true, $manual) . '</td>';
                    $table_row .= '<td class="taxrate"><input type="hidden" value="'.$item['gst'].'" name="' . $items_indicator . '[' . $i . '][taxrate1]" >';
                    
                    $table_row .= '<select class="selectpicker display-block tax" data-width="100%" name="taxname[]" id="taxname" multiple data-none-selected-text="" disabled>';
                      //  $select .= '<option value=""'.(count($default_tax) == 0 ? ' selected' : '').'>'._l('no_tax').'</option>';
                        foreach($taxes as $tax){
                        $selected = "";
                        if($tax['taxrate'] == $item['gst']){
                            $selected = ' selected ';
                        }
                                  
                         
                        $table_row .= '<option value="'.$tax['name'].'|'.$tax['taxrate'].'"'.$selected.'data-taxrate="'.$tax['taxrate'].'" data-taxname="'.$tax['name'].'" data-subtext="'.$tax['name'].'">'.$tax['taxrate'].'%</option>';
                        }
                        $table_row .= '</select></td>';
                    
                    $table_row .= '<td class="amount" align="right">' . $item['grand_total'] . '</td>';
                    if($order->order_type == "Mobile")
                    {
                        $table_row .= '<td></td>';
                    }else {
                        $table_row .= '<td><a href="#" class="btn btn-danger pull-left" onclick="delete_item(this,' . $item['id'] . '); return false;"><i class="fa fa-times"></i></a></td>';
                    }
                    
                    if (isset($item['task_id'])) {
                      if (!is_array($item['task_id'])) {
                        $table_row .= form_hidden('billed_tasks['.$i.'][]', $item['task_id']);
                      } else {
                        foreach ($item['task_id'] as $task_id) {
                          $table_row .= form_hidden('billed_tasks['.$i.'][]', $task_id);
                        }
                      }
                    } else if (isset($item['expense_id'])) {
                      $table_row .= form_hidden('billed_expenses['.$i.'][]', $item['expense_id']);
                    }
                    $table_row .= '</tr>';
                    echo $table_row;
                    $i++;
                  }
                  }
                  ?>
            </tbody>
         </table>
      </div>
      <div class="col-md-6">
        <table class="table text-right">
            <tbody>
                <tr id="subtotal">
                  <td class="total_crates"><span class="bold">Total Crates :</span>
                  <input type="hidden" name="total_crates" value="">
                  </td>
                  <td class="crates"></td>
                  <td class="total_cases"><span class="bold">Total Cases :</span>
                  <input type="hidden" name="total_cases" value="">
                  <input type="hidden" name="total_tax" value="">
                  </td>
                  <td class="cases"></td>
               </tr>
            </tbody>
        </table>
        </div>
      <div class="col-md-6">
         <table class="table text-right">
            <tbody>
                
                
               
               <tr id="subtotal">
                  <td><span class="bold"><?php echo _l('invoice_subtotal'); ?> :</span>
                  </td>
                  <td class="subtotal">
                  </td>
               </tr>
               <tr id="discount_area">
                  <td>
                     <div class="row">
                        <div class="col-md-12">
                           <span class="bold">
                            <?php echo _l('order_discount'); ?>
                         </span>
                        </div>
                        <!--<div class="col-md-5">
                            <div class="input-group" id="discount-total">

                                <input type="number" value="<?php echo (isset($order) ? $order->discount_percent : 0); ?>" class="form-control pull-left input-discount-percent<?php if(isset($order) && !is_sale_discount($order,'percent') && is_sale_discount_applied($order)){echo ' hide';} ?>" min="0" max="100" name="discount_percent">

                                <input type="number" data-toggle="tooltip" data-title="<?php echo _l('numbers_not_formatted_while_editing'); ?>" value="<?php echo (isset($order) ? $order->discount_total : 0); ?>" class="form-control pull-left input-discount-fixed<?php if(!isset($order) || (isset($order) && !is_sale_discount($order,'fixed'))){echo ' hide';} ?>" min="0" name="discount_total">

                                <div class="input-group-addon">
                                  <div class="dropdown">
                                    <a class="dropdown-toggle" href="#" id="dropdown_menu_tax_total_type" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                      <span class="discount-total-type-selected">
                                        <?php if(!isset($order) || isset($order) && (is_sale_discount($order,'percent') || !is_sale_discount_applied($order))) {
                                          echo '%';
                                        } else {
                                          echo _l('discount_fixed_amount');
                                        }
                                        ?>
                                      </span>
                                      <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" id="discount-total-type-dropdown" aria-labelledby="dropdown_menu_tax_total_type">
                                      <li>
                                        <a href="#" class="discount-total-type discount-type-percent<?php if(!isset($order) || (isset($order) && is_sale_discount($order,'percent')) || (isset($order) && !is_sale_discount_applied($order))){echo ' selected';} ?>">%</a>
                                      </li>
                                      <li><a href="#" class="discount-total-type discount-type-fixed<?php if(isset($order) && is_sale_discount($order,'fixed')){echo ' selected';} ?>">
                                          <?php echo _l('discount_fixed_amount'); ?>
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                            </div>
                        </div>-->
                     </div>
                  </td>
                  <td class="discount-total"></td>
               </tr>
               <!--<tr>
                  <td>
                     <div class="row">
                        <div class="col-md-7">
                           <span class="bold"><?php echo _l('invoice_adjustment'); ?></span>
                        </div>
                        <div class="col-md-5">
                           <input type="number" data-toggle="tooltip" data-title="<?php echo _l('numbers_not_formatted_while_editing'); ?>" value="<?php if(isset($order)){echo $order->adjustment; } else { echo 0; } ?>" class="form-control pull-left" name="adjustment">
                        </div>
                     </div>
                  </td>
                  <td class="adjustment"></td>
               </tr>-->
               <tr class="cgsttotaltr">
                  <td><span class="bold"><?php echo _l('CGST_Amt'); ?> :</span>
                  </td>
                  <td class="cgsttotal">
                  </td>
               </tr>
               <tr class="sgsttotaltr">
                  <td><span class="bold"><?php echo _l('SGST_Amt'); ?> :</span>
                  </td>
                  <td class="sgsttotal">
                  </td>
               </tr>
               <tr class="igsttotaltr">
                  <td><span class="bold"><?php echo _l('IGST_Amt'); ?> :</span>
                  </td>
                  <td class="igsttotal">
                  </td>
               </tr>
               <tr>
                  <td><span class="bold"><?php echo _l('invoice_total'); ?> :</span>
                  </td>
                  <td class="total">
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
      <div id="removed-items"></div>
      <div id="billed-tasks"></div>
      <div id="billed-expenses"></div>
      <?php echo form_hidden('task_id'); ?>
      <?php echo form_hidden('expense_id'); ?>  
               
               

      </div>
     
   </div>
   
   <div class="row">
      <div class="col-md-12 mtop15">
         <div class="panel-body bottom-transaction">
            <!--<?php $value = (isset($order) ? $order->clientnote : get_option('predefined_clientnote_invoice')); ?>
            <?php echo render_textarea('clientnote','invoice_add_edit_client_note',$value,array(),array(),'mtop15'); ?>
            <?php $value = (isset($order) ? $order->terms : get_option('predefined_terms_invoice')); ?>
            <?php echo render_textarea('terms','terms_and_conditions',$value,array(),array(),'mtop15'); ?>-->
            <div class="btn-bottom-toolbar text-right">
                <?php if(!isset($order)){ ?>
               <!-- <button class="btn-tr btn btn-default mleft10 text-right invoice-form-submit save-as-draft transaction-submit">
                <?php echo _l('save_as_draft'); ?>
                </button>-->
                <?php } ?>
              <div class="btn-group dropup">
                  <?php
            if($order->order_type == "Mobile") {}else{ ?>
                <button type="button" class="btn-tr btn btn-info invoice-form-submit transaction-submit"><?php echo _l('submit'); ?></button>
               <?php } ?>
               <!--<button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="caret"></span>
                </button>-->
                <!--<ul class="dropdown-menu dropdown-menu-right width200">
                  <li>
                    <a href="#" class="invoice-form-submit save-and-send transaction-submit">
                      <?php echo _l('save_and_send'); ?>
                    </a>
                  </li>
                  <?php if(!isset($order)) { ?>
                  <li>
                    <a href="#" class="invoice-form-submit save-and-send-later transaction-submit">
                      <?php echo _l('save_and_send_later'); ?>
                    </a>
                  </li>
                  <li>
                      <a href="#" class="invoice-form-submit save-and-record-payment transaction-submit">
                        <?php echo _l('save_and_record_payment'); ?>
                      </a>
                  </li>
                <?php } ?>
                </ul>-->
              </div>
             </div>
         </div>
        <!--<div class="btn-bottom-pusher"></div>-->
      </div>
   </div>
</div>
<style>
    ._transaction_form .table.items thead>tr>th {
    min-width: 70px;
}
</style>
<!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- jQuery UI -->
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script type='text/javascript'>
    $(document).ready(function(){
    
    /*$('.number1').on('blur', function() {
        var NestId = $(".number1").val();
        var url = admin_url + 'order/list_orders/' + NestId;
        window.location.href = url;
        //init_order(NestId);
     });*/
     $('.search_order').on('click', function() {
         
        var NestId = 'ORD' + $(".years").val() + $(".number1").val();
        var url = admin_url + 'order/list_orders/' + NestId;
        window.location.href = url;
        //init_order(NestId);
        //alert(NestId);
     });
     
     
     // Initialize 
     $( "#autouser" ).autocomplete({
        
        source: function( request, response ) {
          // Fetch data
          var location = $("#location_typevalue").val();
          var dist_type_id = $("#customer_group_id").val();
          var dist_state_id = $("#customer_state_id").val();
          var item_divistion = $("#item_divistion").val();
          var item_taxes = $("#taxes").val();
          $.ajax({
            url: "<?=base_url()?>admin/order/itemlist",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term,
              location: location,
              dist_type_id: dist_type_id,
              dist_state_id: dist_state_id,
              item_divistion: item_divistion,
              item_taxes: item_taxes
            },
            success: function( data ) {
              response( data );
            }
          });
        },
        select: function (event, ui) {
          
          var item_taxes1 = $("#taxes").val();
          
          if(item_taxes1 == "TaxItems") {
              
              if(ui.item.gst != 1){
                  
                  // Set selection
          $('#autouser').val(ui.item.label); // display the selected text
          
                  add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
                  $('#userid').val(ui.item.value); // save selected id to input
          return false;
              }else {
                  alert("please add only taxable item");
                  // Set selection
          $('#autouser').val(""); // display the selected text
                  return false;
              }
          }
          
          if(item_taxes1 == "NonTaxItems"){
              if(ui.item.gst == 1){
                  
                  // Set selection
                $('#autouser').val(ui.item.label); // display the selected text
          
                  add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
                  $('#userid').val(ui.item.value); // save selected id to input
                return false;
              }else {
                  alert("please add only non taxable item");
                  // Set selection
          $('#autouser').val(""); // display the selected text
          return false;
              }
              
          }
          
          if(item_taxes1 == ""){
              // Set selection
          $('#autouser').val(ui.item.label); // display the selected text
              add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
              $('#userid').val(ui.item.value); // save selected id to input
          return false;
          }
          
          //add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
          
        }
      });
      
      // Initialize 
     $( "#item_code" ).autocomplete({
        
        source: function( request, response ) {
          // Fetch data
          var location = $("#location_typevalue").val();
          var dist_type_id = $("#customer_group_id").val();
          var dist_state_id = $("#customer_state_id").val();
          var item_divistion = $("#item_divistion").val();
          var item_taxes = $("#taxes").val();
          $.ajax({
            url: "<?=base_url()?>admin/order/itemlist_using_itemcode",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term,
              location: location,
              dist_type_id: dist_type_id,
              dist_state_id: dist_state_id,
              item_divistion: item_divistion,
              item_taxes: item_taxes
            },
            beforeSend: function () {
               
               $('#serchh').css('display','block');
               //$("#ui-id-2").prepend("<li value='' class='ui-menu-item'>Serching</li>");
            },
            complete: function () {
                //$("#item_code").val("");
                $('#serchh').css('display','none');
            },
            success: function( data ) {
                
              response( data );
            }
          });
        },
        select: function (event, ui) {
          var item_taxes1 = $("#taxes").val();
          
          if(item_taxes1 == "TaxItems") {
              
              if(ui.item.gst != 1){
                  
                  // Set selection
          $('#item_code').val(ui.item.label); // display the selected text
          
                  add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
                  $('#userid').val(ui.item.value); // save selected id to input
          return false;
              }else {
                  alert("please add only taxable item");
                  // Set selection
          $('#item_code').val(""); // display the selected text
                  return false;
              }
          }
          
          if(item_taxes1 == "NonTaxItems"){
              if(ui.item.gst == 1){
                  
                  // Set selection
                $('#autouser').val(ui.item.label); // display the selected text
          
                  add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
                  $('#userid').val(ui.item.value); // save selected id to input
                return false;
              }else {
                  alert("please add only non taxable item");
                  // Set selection
          $('#item_code').val(""); // display the selected text
          return false;
              }
              
          }
          
          if(item_taxes1 == ""){
              // Set selection
          $('#item_code').val(ui.item.label); // display the selected text
              add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
              $('#userid').val(ui.item.value); // save selected id to input
          return false;
          }
          
          //add_item_to_preview1(ui.item.value,ui.item.location,ui.item.dist_type_id,ui.item.dist_state_id);
        }
      });


    });
    
    
    </script>
    
   
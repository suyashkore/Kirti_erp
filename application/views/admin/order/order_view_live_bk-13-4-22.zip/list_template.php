<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<style>
    .table-order tbody{
  display: block;
  max-height: 350px;
  overflow-y: scroll;
}
.table-order thead, .table-order tbody tr{
  display: table;
  table-layout: fixed;
  width: 100%;
}
.table-order thead{
  width: calc(100% - 1.1em);
}
.table-order thead{
  position: relative;
}
.table-order thead th:last-child:after{
  content: ' ';
  position: absolute;
  background-color: #337ab7;
  width: 1.3em;
  height: 38px;
  right: -1.3em;
  top: 0;
  border-bottom: 2px solid #ddd;
}
</style>
<div class="col-md-12">
   <div class="panel_s mbot10">
      <div class="panel-body _buttons">
         <?php $this->load->view('admin/invoices/invoices_top_stats'); ?>
         <?php if(has_permission('orders','','create')){ ?>
            <a href="<?php echo admin_url('order/order'); ?>" class="btn btn-info pull-left new new-invoice-list mright5">Create New Order</a>
         <?php } ?>
         <?php if(!isset($project)){ ?>
              <!-- <a href="<?php echo admin_url('invoices/recurring'); ?>" class="btn btn-info pull-left">
                  <?php echo _l('invoices_list_recurring'); ?>
               </a>-->
         <?php } ?>
         <div class="display-block text-right">
            
            <!--<a href="#" class="btn btn-default btn-with-tooltip toggle-small-view hidden-xs" onclick="toggle_small_view('.table-invoices','#invoice'); return false;" data-toggle="tooltip" title="<?php echo _l('invoices_toggle_table_tooltip'); ?>"><i class="fa fa-angle-double-left"></i></a>-->
           <!-- <a href="#" class="btn btn-default btn-with-tooltip invoices-total" onclick="slideToggle('#stats-top'); init_invoices_total(true); return false;" data-toggle="tooltip" title="<?php echo _l('view_stats_tooltip'); ?>"><i class="fa fa-bar-chart"></i></a>-->
         </div>
      </div>
   </div>
   <div class="row">
      <div class="col-md-12" id="small-table">
         <div class="panel_s">
            <div class="panel-body">
               <!-- if invoiceid found in url -->
               <?php echo form_hidden('invoiceid',$invoiceid); ?>
               <?php $this->load->view('admin/order/table_html'); ?>
            </div>
         </div>
      </div>
      <div class="col-md-7 small-table-right-col">
         <div id="invoice" class="hide">
         </div>
      </div>
   </div>
</div>
